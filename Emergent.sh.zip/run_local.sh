#!/bin/bash

# 🌌 Emergent.sh Local Launcher
# Quick start script for the Offline Agentic Vibe-Coding Platform

echo "
 ___                                   _         _     
| __|_ __  ___ _ _ __ _ ___ _ _ ___ | |_   ___| |_   
| _|| '  \/ -_) '_/ _\` / -_) ' (_-< | ' \ (_-< ' \\  
|___|_|_|_\___|_| \__, \___|_||_/__/ |_||_//__/_||_| 
                  |___/                               
"

echo "🚀 Starting Emergent.sh Offline Platform..."
echo ""

# Check if services are running
if ! pgrep -f "uvicorn" > /dev/null; then
    echo "⚠️  Backend not running. Starting..."
    cd /app/backend && uvicorn server:app --host 0.0.0.0 --port 8001 &
    sleep 3
fi

if ! pgrep -f "react-scripts" > /dev/null; then
    echo "⚠️  Frontend not running. Starting..."
    cd /app/frontend && yarn start &
    sleep 5
fi

echo ""
echo "✅ Emergent.sh is running!"
echo ""
echo "🌐 Frontend:     http://localhost:3000"
echo "🔌 Backend API:  http://localhost:8001/api"
echo "📚 Docs:         http://localhost:8001/docs"
echo ""
echo "🎯 Quick Start:"
echo "  1. Open http://localhost:3000 in your browser"
echo "  2. Enter your app idea in natural language"
echo "  3. Add vibe keywords (cosmic, serene, minimal, etc.)"
echo "  4. Click 'Generate Project'"
echo "  5. Watch the magic happen! ✨"
echo ""
echo "🛑 To stop: Press Ctrl+C or run 'sudo supervisorctl stop all'"
echo ""
echo "Made with 🌟 and cosmic vibes"
