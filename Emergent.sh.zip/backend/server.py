from fastapi import FastAPI, APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone

# Import Emergent Engine
from emergent_engine import EmergentEngine
from emergent_engine.ws_handlers import ConnectionManager, WebSocketEventBroker

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Initialize Emergent Engine Phase 3
emergent = EmergentEngine(db=db)

# Phase 3: WebSocket manager
ws_manager = ConnectionManager()
ws_broker = WebSocketEventBroker(ws_manager)

# Create the main app without a prefix
app = FastAPI(title="Emergent.sh Offline Platform - Phase 3")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    model_config = ConfigDict(extra="ignore")  # Ignore MongoDB's _id field
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str

class GenerateRequest(BaseModel):
    prompt: str
    vibes: Optional[str] = ""
    temperature: Optional[float] = 0.7
    
class ChatRequest(BaseModel):
    message: str
    context: Optional[List[Dict]] = []

class ModelConfig(BaseModel):
    model_name: str
    quantize: Optional[bool] = False

class AgentToggle(BaseModel):
    agent_name: str
    enabled: bool

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {
        "message": "Emergent.sh Offline Platform", 
        "version": "1.0.0",
        "status": "online"
    }

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    
    # Convert to dict and serialize datetime to ISO string for MongoDB
    doc = status_obj.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    
    _ = await db.status_checks.insert_one(doc)
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    # Exclude MongoDB's _id field from the query results
    status_checks = await db.status_checks.find({}, {"_id": 0}).to_list(1000)
    
    # Convert ISO string timestamps back to datetime objects
    for check in status_checks:
        if isinstance(check['timestamp'], str):
            check['timestamp'] = datetime.fromisoformat(check['timestamp'])
    
    return status_checks

# ========== EMERGENT ENGINE ROUTES ==========

@api_router.post("/emergent/generate")
async def generate_project(request: GenerateRequest):
    """Generate a full-stack project from a natural language prompt"""
    try:
        result = await emergent.generate_project(
            user_request=request.prompt,
            vibes=request.vibes,
            temperature=request.temperature
        )
        
        if result['success']:
            # Store project in database
            project_doc = result['project'].copy()
            project_doc['created_at'] = datetime.now(timezone.utc).isoformat()
            await db.projects.insert_one(project_doc)
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/emergent/chat")
async def chat(request: ChatRequest):
    """Conversational interface with Emergent"""
    try:
        response = await emergent.chat(request.message, request.context)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/projects")
async def list_projects():
    """List all generated projects"""
    try:
        projects = await db.projects.find({}, {"_id": 0}).to_list(100)
        return {"projects": projects}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/project/{project_id}")
async def get_project(project_id: str):
    """Get a specific project by ID"""
    try:
        project = await db.projects.find_one({"id": project_id}, {"_id": 0})
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        return project
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/emergent/model/load")
async def load_model(config: ModelConfig):
    """Load a Hugging Face model"""
    try:
        success = emergent.load_model(config.model_name, config.quantize)
        if success:
            return {"message": f"Model {config.model_name} loaded successfully"}
        else:
            raise HTTPException(status_code=500, detail="Failed to load model")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/models")
async def list_models():
    """List available Hugging Face models"""
    models = [
        {
            "name": "mistralai/Mixtral-8x7B-Instruct-v0.1",
            "description": "Mixtral 8x7B - High quality, resource intensive",
            "size": "~47GB",
            "recommended": True
        },
        {
            "name": "mistralai/Mistral-7B-Instruct-v0.2",
            "description": "Mistral 7B - Good balance of quality and speed",
            "size": "~14GB",
            "recommended": True
        },
        {
            "name": "meta-llama/Llama-3.2-3B-Instruct",
            "description": "Llama 3.2 3B - Lightweight, fast",
            "size": "~6GB",
            "recommended": False
        },
        {
            "name": "HuggingFaceH4/zephyr-7b-beta",
            "description": "Zephyr 7B - Fast and efficient",
            "size": "~14GB",
            "recommended": False
        }
    ]
    return {"models": models}

@api_router.post("/emergent/agent/toggle")
async def toggle_agent(toggle: AgentToggle):
    """Enable or disable a specific agent"""
    try:
        emergent.toggle_agent(toggle.agent_name, toggle.enabled)
        return {
            "message": f"Agent {toggle.agent_name} {'enabled' if toggle.enabled else 'disabled'}",
            "agents": emergent.active_agents
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========== PHASE 2 ROUTES ==========

@api_router.get("/emergent/system/info")
async def get_system_info():
    """Get Phase 2 system information and status"""
    try:
        return emergent.get_system_info()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/providers")
async def list_providers():
    """List available model providers"""
    try:
        return {
            "available": emergent.model_router.get_available_providers(),
            "active": emergent.model_router.get_active_provider(),
            "priority": emergent.model_router.priority
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class ProviderConfig(BaseModel):
    priority: List[str]

@api_router.post("/emergent/providers/priority")
async def set_provider_priority(config: ProviderConfig):
    """Set model provider priority order"""
    try:
        emergent.model_router.set_priority(config.priority)
        return {
            "message": "Priority updated",
            "priority": emergent.model_router.priority
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class MemoryQuery(BaseModel):
    agent_id: str
    query: Optional[str] = None

@api_router.post("/emergent/memory/recall")
async def recall_memories(query: MemoryQuery):
    """Retrieve agent memories"""
    try:
        memories = await emergent.get_agent_memories(query.agent_id, query.query)
        return {"memories": memories}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class ReflectionRequest(BaseModel):
    agent_id: str
    topic: str

@api_router.post("/emergent/memory/reflect")
async def reflect_on_topic(request: ReflectionRequest):
    """Have an agent reflect on a topic"""
    try:
        reflection = await emergent.reflect_on_topic(request.agent_id, request.topic)
        return {"reflection": reflection}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========== PHASE 3 ROUTES ==========

class AgentMessage(BaseModel):
    from_agent: str
    to_agent: str
    msg_type: str
    payload: Dict[str, Any]

@api_router.post("/emergent/agent/message")
async def send_agent_message(message: AgentMessage):
    """Send inter-agent message"""
    try:
        success = await emergent.send_agent_message(
            from_agent=message.from_agent,
            to_agent=message.to_agent,
            msg_type=message.msg_type,
            payload=message.payload
        )
        return {"success": success, "message": "Message sent" if success else "Failed to send"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/agent/messages/{agent_id}")
async def get_agent_messages(agent_id: str, limit: int = 100):
    """Get message history for an agent"""
    try:
        messages = await emergent.get_agent_message_history(agent_id, limit)
        return {"messages": messages}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class TaskGraphRequest(BaseModel):
    tasks: List[Dict[str, Any]]

@api_router.post("/emergent/graph/plan")
async def create_task_graph(request: TaskGraphRequest):
    """Create a new task graph"""
    try:
        graph = await emergent.create_task_graph(request.tasks)
        if graph:
            return {"success": True, "graph_id": graph.graph_id, "graph": graph.to_dict()}
        else:
            raise HTTPException(status_code=400, detail="Failed to create graph")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/graph/status/{graph_id}")
async def get_graph_status(graph_id: str):
    """Get task graph status"""
    try:
        graph_data = await emergent.get_task_graph_status(graph_id)
        if graph_data:
            return graph_data
        else:
            raise HTTPException(status_code=404, detail="Graph not found")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/emergent/graph/trigger/{graph_id}")
async def trigger_graph_execution(graph_id: str):
    """Trigger execution of a task graph"""
    try:
        success = await emergent.execute_task_graph(graph_id)
        return {"success": success, "graph_id": graph_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class CoTStepRequest(BaseModel):
    agent_id: str
    thought: str
    reason: str
    confidence: Optional[float] = 0.5
    sources: Optional[List[str]] = None

@api_router.post("/emergent/agent/thoughts")
async def add_cot_step(request: CoTStepRequest):
    """Add a chain-of-thought step"""
    try:
        success = await emergent.add_cot_step(
            agent_id=request.agent_id,
            thought=request.thought,
            reason=request.reason,
            confidence=request.confidence,
            sources=request.sources
        )
        return {"success": success}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/agent/thoughts/{session_id}")
async def get_cot_steps(session_id: str, agent_id: str):
    """Get chain-of-thought steps for a session"""
    try:
        steps = await emergent.get_cot_steps(agent_id, session_id)
        summary = await emergent.get_cot_summary(agent_id, session_id)
        return {"steps": steps, "summary": summary}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/vibe/ontology")
async def get_vibe_ontology():
    """Get vibe ontology"""
    try:
        ontology = emergent.load_vibe_ontology()
        return {"ontology": ontology}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/emergent/vibe/state")
async def get_vibe_state():
    """Get current vibe state"""
    try:
        state = emergent.get_vibe_state()
        return {"vibe": state}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class VibeRequest(BaseModel):
    vibe_name: str

@api_router.post("/emergent/vibe/set")
async def set_vibe(request: VibeRequest):
    """Set active vibe"""
    try:
        success = emergent.set_active_vibe(request.vibe_name)
        if success:
            return {"success": True, "vibe": emergent.get_vibe_state()}
        else:
            raise HTTPException(status_code=400, detail="Invalid vibe name")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========== WEBSOCKET ROUTES ==========

@app.websocket("/ws/inspect")
async def websocket_inspect(websocket: WebSocket, session_id: Optional[str] = None):
    """WebSocket endpoint for system inspection"""
    await ws_manager.connect(websocket, "inspect", session_id)
    try:
        while True:
            # Keep connection alive and handle incoming messages
            data = await websocket.receive_text()
            # Echo back for now (can add command handling later)
            await websocket.send_json({"type": "ack", "data": data})
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, "inspect", session_id)

@app.websocket("/ws/agents")
async def websocket_agents(websocket: WebSocket):
    """WebSocket endpoint for agent messages"""
    await ws_manager.connect(websocket, "agents")
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({"type": "ack", "data": data})
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, "agents")

@app.websocket("/ws/memory")
async def websocket_memory(websocket: WebSocket):
    """WebSocket endpoint for memory updates"""
    await ws_manager.connect(websocket, "memory")
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({"type": "ack", "data": data})
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, "memory")

@app.websocket("/ws/graph")
async def websocket_graph(websocket: WebSocket):
    """WebSocket endpoint for task graph updates"""
    await ws_manager.connect(websocket, "graph")
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({"type": "ack", "data": data})
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, "graph")

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def startup_event():
    """Initialize Phase 3 components on startup"""
    try:
        await emergent.initialize_phase3()
        await ws_broker.start(
            agent_bus=emergent.agent_bus,
            reflective_memory=emergent.reflective_memory,
            task_graph_manager=emergent.task_graph_manager
        )
        logger.info("Phase 3 components initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize Phase 3: {e}")

@app.on_event("shutdown")
async def shutdown_db_client():
    await ws_broker.stop()
    await emergent.agent_bus.close()
    client.close()
    logger.info("Shutdown complete")