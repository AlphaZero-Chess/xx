#!/usr/bin/env python3
"""
Phase 2 Test Script
Tests model routing and reflective memory functionality
"""

import asyncio
import logging
from emergent_engine.models import ModelRouter
from emergent_engine.memory import RedisMemoryAdapter, MemoryStore, EmbeddingEngine, ReflectiveMemory

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_model_router():
    """Test model router functionality"""
    logger.info("=== Testing Model Router ===")
    
    router = ModelRouter()
    
    # Check available providers
    available = router.get_available_providers()
    logger.info(f"Available providers: {available}")
    
    # Load simulated model
    success = router.load_model("simulated", provider="simulated")
    logger.info(f"Simulated model loaded: {success}")
    
    # Test generation
    response = router.generate(
        prompt="Create a simple todo app",
        system_prompt="You are ArchitectAgent",
        temperature=0.7
    )
    logger.info(f"Generated response: {response[:200]}...")
    
    logger.info("✅ Model Router tests passed\n")

async def test_memory_system():
    """Test memory system functionality"""
    logger.info("=== Testing Memory System ===")
    
    # Initialize memory components
    redis_adapter = RedisMemoryAdapter()
    logger.info(f"Redis connected: {redis_adapter.is_connected()}")
    
    # Test basic Redis operations
    if redis_adapter.is_connected():
        redis_adapter.remember("test_key", "test_value", ttl=60)
        value = redis_adapter.recall("test_key")
        logger.info(f"Redis recall test: {value}")
        assert value == "test_value", "Redis recall failed"
        redis_adapter.forget("test_key")
        logger.info("✅ Redis basic operations passed")
    else:
        logger.warning("⚠️  Redis not available, skipping Redis tests")
    
    # Test memory store
    memory_store = MemoryStore(redis_adapter, None)
    await memory_store.remember("test_agent", "memory1", {"data": "test"}, persist=False)
    recalled = memory_store.recall("test_agent", "memory1")
    logger.info(f"Memory store recall: {recalled}")
    
    logger.info("✅ Memory system tests passed\n")

async def test_reflective_memory():
    """Test reflective memory with embeddings"""
    logger.info("=== Testing Reflective Memory ===")
    
    # Initialize components
    redis_adapter = RedisMemoryAdapter()
    memory_store = MemoryStore(redis_adapter, None)
    embedding_engine = EmbeddingEngine()
    reflective_memory = ReflectiveMemory(memory_store, embedding_engine)
    
    # Store some memories
    await reflective_memory.remember(
        agent_id="test_agent",
        content="Built a todo app with React and FastAPI",
        importance=0.8
    )
    
    await reflective_memory.remember(
        agent_id="test_agent",
        content="Created a blog platform with user authentication",
        importance=0.7
    )
    
    await reflective_memory.remember(
        agent_id="test_agent",
        content="Designed a dashboard with real-time analytics",
        importance=0.9
    )
    
    # Test semantic recall
    results = await reflective_memory.recall(
        agent_id="test_agent",
        query="web application with authentication",
        top_k=3
    )
    
    logger.info(f"Found {len(results)} relevant memories:")
    for i, result in enumerate(results, 1):
        logger.info(f"{i}. {result['content']} (similarity: {result['similarity']:.3f})")
    
    # Test reflection
    reflection = await reflective_memory.reflect(
        agent_id="test_agent",
        topic="web development"
    )
    logger.info(f"\nReflection:\n{reflection}")
    
    logger.info("✅ Reflective memory tests passed\n")

async def test_integrated_system():
    """Test integrated system"""
    logger.info("=== Testing Integrated System ===")
    
    from emergent_engine.core import EmergentEngine
    
    # Initialize engine
    engine = EmergentEngine()
    
    # Get system info
    info = engine.get_system_info()
    logger.info(f"System info: {info}")
    
    # Test simple generation
    result = await engine.generate_project(
        user_request="Create a simple note-taking app",
        vibes="minimal, clean",
        temperature=0.7
    )
    
    logger.info(f"Generation success: {result['success']}")
    if result['success']:
        logger.info(f"Project name: {result['project'].get('name', 'N/A')}")
        logger.info(f"Metadata: {result['metadata']}")
    
    logger.info("✅ Integrated system tests passed\n")

async def main():
    """Run all tests"""
    try:
        await test_model_router()
        await test_memory_system()
        await test_reflective_memory()
        await test_integrated_system()
        
        logger.info("=" * 60)
        logger.info("🎉 All Phase 2 tests passed!")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"❌ Test failed: {e}", exc_info=True)
        raise

if __name__ == "__main__":
    asyncio.run(main())
