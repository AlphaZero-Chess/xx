#!/usr/bin/env python3
"""
Diagnostic Trace for Phase 3 Issues
Analyzes Task Graph Schema and Agent Bus Connection
"""

import asyncio
import logging
import json
from motor.motor_asyncio import AsyncIOMotorClient
from emergent_engine import EmergentEngine
from emergent_engine.agent_bus import AgentBus, Message

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def diagnostic_task_graph():
    """
    ISSUE #1: Task Graph Schema Alignment
    Trace: create_task_graph() -> TaskGraphManager -> API response
    """
    logger.info("=" * 80)
    logger.info("DIAGNOSTIC #1: Task Graph Schema Alignment")
    logger.info("=" * 80)
    
    try:
        # Initialize DB
        client = AsyncIOMotorClient("mongodb://localhost:27017")
        db = client["test_database"]
        
        # Initialize engine
        engine = EmergentEngine(db=db)
        await engine.initialize_phase3()
        
        # Test task graph creation with valid schema
        test_tasks = [
            {
                "task_id": "task_1",
                "role": "architect",
                "action": "design_system",
                "params": {"requirement": "web app"},
                "deps": []
            },
            {
                "task_id": "task_2",
                "role": "coder",
                "action": "generate_code",
                "params": {"architecture": "from_task_1"},
                "deps": ["task_1"]
            }
        ]
        
        logger.info(f"\n📋 Input Tasks Schema:")
        logger.info(json.dumps(test_tasks, indent=2))
        
        # Call the method
        logger.info("\n🔧 Calling engine.create_task_graph()...")
        graph = await engine.create_task_graph(test_tasks)
        
        if graph:
            logger.info("\n✅ Graph Created Successfully!")
            logger.info(f"Graph ID: {graph.graph_id}")
            logger.info(f"Graph Type: {type(graph)}")
            
            # Check what to_dict() returns
            graph_dict = graph.to_dict()
            logger.info(f"\n📊 Graph.to_dict() Output:")
            logger.info(json.dumps(graph_dict, indent=2, default=str))
            
            # Simulate API response
            api_response = {
                "success": True, 
                "graph_id": graph.graph_id, 
                "graph": graph_dict
            }
            logger.info(f"\n🌐 Expected API Response:")
            logger.info(json.dumps(api_response, indent=2, default=str))
            
            logger.info("\n✅ ISSUE #1 DIAGNOSIS: Schema appears correct!")
            logger.info("   - create_task_graph() returns TaskGraph instance ✓")
            logger.info("   - graph.graph_id accessible ✓")
            logger.info("   - graph.to_dict() returns dict ✓")
            logger.info("   - API can construct proper response ✓")
            
        else:
            logger.error("\n❌ ISSUE FOUND: create_task_graph() returned None")
            logger.error("   Root Cause: Graph validation or creation failed")
            
        await engine.agent_bus.close()
        client.close()
        
    except Exception as e:
        logger.error(f"\n❌ EXCEPTION in Task Graph Test: {e}", exc_info=True)
        logger.error(f"   Root Cause: {type(e).__name__}: {str(e)}")


async def diagnostic_agent_bus():
    """
    ISSUE #2: Agent Bus Async Connection
    Trace: connect() -> publish() -> message delivery
    """
    logger.info("\n" + "=" * 80)
    logger.info("DIAGNOSTIC #2: Agent Bus Async Connection")
    logger.info("=" * 80)
    
    try:
        # Initialize DB
        client = AsyncIOMotorClient("mongodb://localhost:27017")
        db = client["test_database"]
        
        # Test 1: Direct AgentBus Connection
        logger.info("\n🔌 Test 1: Direct AgentBus.connect()")
        agent_bus = AgentBus(db=db)
        
        logger.info(f"   Initial connection status: {agent_bus.connected}")
        
        # Call connect
        logger.info("   Calling await agent_bus.connect()...")
        await agent_bus.connect()
        
        logger.info(f"   Post-connect status: {agent_bus.connected}")
        logger.info(f"   Redis instance: {agent_bus.redis}")
        
        if agent_bus.connected:
            logger.info("   ✅ Agent Bus connected successfully!")
            
            # Test 2: Message Publishing
            logger.info("\n📤 Test 2: Message Publishing")
            test_message = Message(
                from_agent="test_sender",
                to_agent="test_receiver",
                msg_type="test",
                payload={"data": "test_payload"}
            )
            
            logger.info("   Calling await agent_bus.publish()...")
            success = await agent_bus.publish(test_message)
            logger.info(f"   Publish result: {success}")
            
            if success:
                logger.info("   ✅ Message published successfully!")
            else:
                logger.error("   ❌ ISSUE: Message publish failed")
                logger.error("      Root Cause: publish() returned False")
        else:
            logger.error("   ❌ ISSUE FOUND: Agent Bus failed to connect")
            logger.error("      Checking Redis availability...")
            
            # Test Redis directly
            import redis.asyncio as redis_async
            try:
                redis_client = redis_async.Redis.from_url(
                    "redis://localhost:6379",
                    decode_responses=True
                )
                await redis_client.ping()
                logger.info("      Redis is available and responding to ping ✓")
                logger.error("      Root Cause: Connection logic issue in AgentBus.connect()")
            except Exception as redis_err:
                logger.error(f"      Redis unavailable: {redis_err}")
                logger.error("      Root Cause: Redis service not running")
        
        # Test 3: Integration with EmergentEngine
        logger.info("\n🔄 Test 3: EmergentEngine Integration")
        engine = EmergentEngine(db=db)
        logger.info(f"   Engine agent_bus.connected: {engine.agent_bus.connected}")
        
        logger.info("   Calling await engine.initialize_phase3()...")
        await engine.initialize_phase3()
        
        logger.info(f"   Post-init agent_bus.connected: {engine.agent_bus.connected}")
        
        if engine.agent_bus.connected:
            logger.info("   ✅ Integration successful!")
            
            # Test send_agent_message
            logger.info("\n💬 Test 4: send_agent_message() API")
            success = await engine.send_agent_message(
                from_agent="coder",
                to_agent="architect",
                msg_type="request",
                payload={"question": "What's the architecture?"}
            )
            logger.info(f"   send_agent_message() result: {success}")
            
            if success:
                logger.info("   ✅ API-level message sending works!")
            else:
                logger.error("   ❌ ISSUE: API-level message sending failed")
        else:
            logger.error("   ❌ ISSUE: initialize_phase3() didn't connect agent bus")
            logger.error("      Root Cause: connect() not called or not awaited properly")
        
        await agent_bus.close()
        await engine.agent_bus.close()
        client.close()
        
    except Exception as e:
        logger.error(f"\n❌ EXCEPTION in Agent Bus Test: {e}", exc_info=True)
        logger.error(f"   Root Cause: {type(e).__name__}: {str(e)}")


async def main():
    """Run all diagnostics"""
    logger.info("🚀 Starting Phase 3 Diagnostic Trace\n")
    
    # Run diagnostics
    await diagnostic_task_graph()
    await diagnostic_agent_bus()
    
    logger.info("\n" + "=" * 80)
    logger.info("📊 DIAGNOSTIC SUMMARY")
    logger.info("=" * 80)
    logger.info("Check logs above for:")
    logger.info("  1. Task Graph Schema issues (if any)")
    logger.info("  2. Agent Bus connection issues (if any)")
    logger.info("  3. Root cause analysis for each issue")
    logger.info("=" * 80)


if __name__ == "__main__":
    asyncio.run(main())
