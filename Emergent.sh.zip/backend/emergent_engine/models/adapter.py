"""
Model Adapter Layer for Phase 2
Supports: HuggingFace, Ollama, LM Studio with routing and fallback
"""

import logging
import os
from typing import Optional, Dict, Any, List
from abc import ABC, abstractmethod
import torch

logger = logging.getLogger(__name__)


class ModelAdapter(ABC):
    """Base adapter for LLM providers"""
    
    @abstractmethod
    def load(self, model_name: str, **kwargs) -> bool:
        """Load a model"""
        pass
    
    @abstractmethod
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Generate text from prompt"""
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if adapter is available"""
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """Get adapter name"""
        pass


class HuggingFaceAdapter(ModelAdapter):
    """HuggingFace Transformers adapter for offline-first local models"""
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.model_name = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"HuggingFaceAdapter initialized. Device: {self.device}")
    
    def load(self, model_name: str, quantize: bool = False, **kwargs) -> bool:
        """Load a HuggingFace model"""
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            
            logger.info(f"Loading HF model: {model_name}")
            self.model_name = model_name
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_name,
                trust_remote_code=True
            )
            
            # Load model with optional quantization
            load_kwargs = {
                "trust_remote_code": True,
                "device_map": "auto",
                "torch_dtype": torch.float16
            }
            
            if quantize and torch.cuda.is_available():
                from transformers import BitsAndBytesConfig
                load_kwargs["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16
                )
            
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                **load_kwargs
            )
            
            logger.info(f"HF model loaded successfully: {model_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load HF model {model_name}: {str(e)}")
            return False
    
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Generate text using HuggingFace model"""
        try:
            if self.model is None:
                raise ValueError("Model not loaded")
            
            # Format with system prompt
            full_prompt = f"{system_prompt}\n\nUser: {prompt}\n\nAssistant:" if system_prompt else prompt
            
            # Tokenize
            inputs = self.tokenizer(full_prompt, return_tensors="pt").to(self.device)
            
            # Generate
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    do_sample=True,
                    top_p=0.9,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # Decode
            generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Extract only the assistant's response
            if "Assistant:" in generated_text:
                response = generated_text.split("Assistant:")[-1].strip()
            else:
                response = generated_text
            
            return response
            
        except Exception as e:
            logger.error(f"HF generation failed: {str(e)}")
            raise
    
    def is_available(self) -> bool:
        """Check if HuggingFace is available"""
        try:
            import transformers
            return True
        except ImportError:
            return False
    
    def get_name(self) -> str:
        return "huggingface"


class OllamaAdapter(ModelAdapter):
    """Ollama adapter for easy local LLM deployment"""
    
    def __init__(self):
        self.client = None
        self.model_name = None
        self.base_url = os.environ.get('OLLAMA_BASE_URL', 'http://localhost:11434')
    
    def load(self, model_name: str, **kwargs) -> bool:
        """Load an Ollama model"""
        try:
            import ollama
            
            logger.info(f"Loading Ollama model: {model_name}")
            self.client = ollama.Client(host=self.base_url)
            self.model_name = model_name
            
            # Test connection
            self.client.list()
            logger.info(f"Ollama model configured: {model_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load Ollama model {model_name}: {str(e)}")
            return False
    
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Generate text using Ollama"""
        try:
            if self.client is None or self.model_name is None:
                raise ValueError("Ollama not configured")
            
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            
            response = self.client.chat(
                model=self.model_name,
                messages=messages,
                options={
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            )
            
            return response['message']['content']
            
        except Exception as e:
            logger.error(f"Ollama generation failed: {str(e)}")
            raise
    
    def is_available(self) -> bool:
        """Check if Ollama is available"""
        try:
            import ollama
            client = ollama.Client(host=self.base_url)
            client.list()
            return True
        except:
            return False
    
    def get_name(self) -> str:
        return "ollama"


class LMStudioAdapter(ModelAdapter):
    """LM Studio adapter via OpenAI-compatible API"""
    
    def __init__(self):
        self.model_name = None
        self.base_url = os.environ.get('LM_STUDIO_URL', 'http://localhost:1234/v1')
    
    def load(self, model_name: str, **kwargs) -> bool:
        """Configure LM Studio model"""
        try:
            import requests
            
            logger.info(f"Configuring LM Studio model: {model_name}")
            self.model_name = model_name
            
            # Test connection
            response = requests.get(f"{self.base_url}/models", timeout=5)
            response.raise_for_status()
            
            logger.info(f"LM Studio configured: {model_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to configure LM Studio {model_name}: {str(e)}")
            return False
    
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Generate text using LM Studio"""
        try:
            import requests
            
            if self.model_name is None:
                raise ValueError("LM Studio not configured")
            
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            
            response = requests.post(
                f"{self.base_url}/chat/completions",
                json={
                    "model": self.model_name,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens
                },
                timeout=120
            )
            response.raise_for_status()
            
            return response.json()['choices'][0]['message']['content']
            
        except Exception as e:
            logger.error(f"LM Studio generation failed: {str(e)}")
            raise
    
    def is_available(self) -> bool:
        """Check if LM Studio is available"""
        try:
            import requests
            response = requests.get(f"{self.base_url}/models", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def get_name(self) -> str:
        return "lmstudio"


class SimulatedAdapter(ModelAdapter):
    """Simulated adapter for testing and demos"""
    
    def __init__(self):
        self.model_name = "simulated"
    
    def load(self, model_name: str, **kwargs) -> bool:
        self.model_name = model_name
        logger.info("Using simulated adapter")
        return True
    
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Return structured simulated responses"""
        
        # Determine agent type from system prompt
        if "ArchitectAgent" in system_prompt:
            return self._architect_simulation()
        elif "CoderAgent" in system_prompt:
            return self._coder_simulation()
        elif "DesignerAgent" in system_prompt:
            return self._designer_simulation()
        elif "DevOpsAgent" in system_prompt:
            return self._devops_simulation()
        elif "CriticAgent" in system_prompt:
            return self._critic_simulation()
        else:
            return "Simulated response: Processing your request..."
    
    def _architect_simulation(self) -> str:
        return '''{
  "architecture": {
    "frontend": "React with Tailwind CSS",
    "backend": "FastAPI with MongoDB",
    "storage": "MongoDB for persistence",
    "realtime": "WebSocket for live updates"
  },
  "endpoints": [
    {"method": "POST", "path": "/api/items", "description": "Create new item"},
    {"method": "GET", "path": "/api/items", "description": "List all items"}
  ],
  "models": [
    {
      "name": "Item",
      "fields": [
        {"name": "id", "type": "string", "required": true},
        {"name": "title", "type": "string", "required": true}
      ]
    }
  ],
  "constraints": {
    "auth": "Optional JWT authentication",
    "persistence": "MongoDB with async driver"
  }
}'''
    
    def _coder_simulation(self) -> str:
        return '''{
  "backend/routes.py": "from fastapi import APIRouter\\n\\nrouter = APIRouter(prefix=\\"/api\\")\\n\\n@router.get(\\\"/items\\\")\\nasync def list_items():\\n    return []",
  "frontend/ItemList.js": "import React from 'react';\\n\\nconst ItemList = () => {\\n  return <div>Item List</div>;\\n};\\n\\nexport default ItemList;"
}'''
    
    def _designer_simulation(self) -> str:
        return '''{
  "palette": {
    "primary": "#6366f1",
    "secondary": "#8b5cf6",
    "accent": "#ec4899"
  },
  "fonts": {
    "heading": "Space Grotesk",
    "body": "Inter"
  }
}'''
    
    def _devops_simulation(self) -> str:
        return '''{
  "dockerfile": "FROM python:3.11-slim\\nWORKDIR /app\\nCOPY . .\\nCMD [\\"uvicorn\\", \\"server:app\\"]"
}'''
    
    def _critic_simulation(self) -> str:
        return '''{
  "issues": [
    {
      "severity": "low",
      "type": "testing",
      "message": "Add unit tests"
    }
  ],
  "score": 85,
  "summary": "Good foundation"
}'''
    
    def is_available(self) -> bool:
        return True
    
    def get_name(self) -> str:
        return "simulated"


class ModelRouter:
    """Routes requests to appropriate model adapter with fallback"""
    
    def __init__(self, priority: Optional[List[str]] = None):
        """
        Initialize router with provider priority
        
        Args:
            priority: List of provider names in order of preference
                     e.g., ['ollama', 'huggingface', 'simulated']
        """
        self.adapters: Dict[str, ModelAdapter] = {
            'huggingface': HuggingFaceAdapter(),
            'ollama': OllamaAdapter(),
            'lmstudio': LMStudioAdapter(),
            'simulated': SimulatedAdapter()
        }
        
        self.priority = priority or ['ollama', 'lmstudio', 'huggingface', 'simulated']
        self.active_adapter: Optional[ModelAdapter] = None
        self.model_name: Optional[str] = None
        
        logger.info(f"ModelRouter initialized with priority: {self.priority}")
    
    def load_model(self, model_name: str, provider: Optional[str] = None, **kwargs) -> bool:
        """
        Load a model with specified or auto-detected provider
        
        Args:
            model_name: Name of the model to load
            provider: Specific provider to use, or None for auto-detection
            **kwargs: Additional arguments for model loading
        """
        providers_to_try = [provider] if provider else self.priority
        
        for provider_name in providers_to_try:
            if provider_name not in self.adapters:
                logger.warning(f"Unknown provider: {provider_name}")
                continue
            
            adapter = self.adapters[provider_name]
            
            # Check availability
            if not adapter.is_available():
                logger.info(f"Provider {provider_name} not available, trying next...")
                continue
            
            # Try to load
            try:
                if adapter.load(model_name, **kwargs):
                    self.active_adapter = adapter
                    self.model_name = model_name
                    logger.info(f"Model loaded successfully: {model_name} via {provider_name}")
                    return True
            except Exception as e:
                logger.error(f"Failed to load via {provider_name}: {str(e)}")
                continue
        
        logger.error(f"Failed to load model {model_name} with any provider")
        return False
    
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Generate text using active adapter"""
        if self.active_adapter is None:
            # Fallback to simulated if no adapter loaded
            logger.warning("No adapter loaded, using simulated")
            self.active_adapter = self.adapters['simulated']
            self.active_adapter.load('simulated')
        
        return self.active_adapter.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens
        )
    
    def get_active_provider(self) -> Optional[str]:
        """Get name of currently active provider"""
        return self.active_adapter.get_name() if self.active_adapter else None
    
    def get_available_providers(self) -> List[str]:
        """Get list of available providers"""
        return [name for name, adapter in self.adapters.items() if adapter.is_available()]
    
    def set_priority(self, priority: List[str]):
        """Update provider priority order"""
        self.priority = priority
        logger.info(f"Priority updated to: {priority}")
