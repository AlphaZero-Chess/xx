import os
import logging
from typing import Optional, Dict, Any
import torch

logger = logging.getLogger(__name__)

class ModelLoader:
    """Handles loading and inference with Hugging Face models"""
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.model_name = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"ModelLoader initialized. Device: {self.device}")
    
    def load_model(self, model_name: str, quantize: bool = False):
        """Load a Hugging Face model"""
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            
            logger.info(f"Loading model: {model_name}")
            self.model_name = model_name
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_name,
                trust_remote_code=True
            )
            
            # Load model with optional quantization
            load_kwargs = {
                "trust_remote_code": True,
                "device_map": "auto",
                "torch_dtype": torch.float16
            }
            
            if quantize and torch.cuda.is_available():
                from transformers import BitsAndBytesConfig
                load_kwargs["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16
                )
            
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                **load_kwargs
            )
            
            logger.info(f"Model loaded successfully: {model_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load model {model_name}: {str(e)}")
            return False
    
    def generate(self, prompt: str, system_prompt: str = "", 
                 temperature: float = 0.7, max_tokens: int = 2048) -> str:
        """Generate text from a prompt"""
        try:
            if self.model is None:
                # Fallback to simulated response if no model loaded
                return self._simulated_generate(prompt, system_prompt)
            
            # Format with system prompt
            full_prompt = f"{system_prompt}\n\nUser: {prompt}\n\nAssistant:"
            
            # Tokenize
            inputs = self.tokenizer(full_prompt, return_tensors="pt").to(self.device)
            
            # Generate
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    do_sample=True,
                    top_p=0.9,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # Decode
            generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Extract only the assistant's response
            if "Assistant:" in generated_text:
                response = generated_text.split("Assistant:")[-1].strip()
            else:
                response = generated_text
            
            return response
            
        except Exception as e:
            logger.error(f"Generation failed: {str(e)}")
            return self._simulated_generate(prompt, system_prompt)
    
    def _simulated_generate(self, prompt: str, system_prompt: str = "") -> str:
        """Simulated response for when no model is loaded"""
        logger.info("Using simulated response (no model loaded)")
        
        # Return structured responses based on agent type
        if "ArchitectAgent" in system_prompt:
            return self._architect_simulation(prompt)
        elif "CoderAgent" in system_prompt:
            return self._coder_simulation(prompt)
        elif "DesignerAgent" in system_prompt:
            return self._designer_simulation(prompt)
        elif "DevOpsAgent" in system_prompt:
            return self._devops_simulation(prompt)
        elif "CriticAgent" in system_prompt:
            return self._critic_simulation(prompt)
        else:
            return "Simulated response: Processing your request..."
    
    def _architect_simulation(self, prompt: str) -> str:
        return '''{
  "architecture": {
    "frontend": "React with Tailwind CSS",
    "backend": "FastAPI with MongoDB",
    "storage": "MongoDB for persistence",
    "realtime": "WebSocket for live updates"
  },
  "endpoints": [
    {"method": "POST", "path": "/api/items", "description": "Create new item"},
    {"method": "GET", "path": "/api/items", "description": "List all items"},
    {"method": "GET", "path": "/api/items/{id}", "description": "Get item by ID"},
    {"method": "PUT", "path": "/api/items/{id}", "description": "Update item"},
    {"method": "DELETE", "path": "/api/items/{id}", "description": "Delete item"}
  ],
  "models": [
    {
      "name": "Item",
      "fields": [
        {"name": "id", "type": "string", "required": true},
        {"name": "title", "type": "string", "required": true},
        {"name": "content", "type": "string", "required": true},
        {"name": "created_at", "type": "datetime", "required": true},
        {"name": "updated_at", "type": "datetime", "required": true}
      ]
    }
  ],
  "constraints": {
    "auth": "Optional JWT authentication",
    "persistence": "MongoDB with async driver",
    "offline_first": false
  }
}'''
    
    def _coder_simulation(self, prompt: str) -> str:
        return '''{
  "backend/routes.py": "from fastapi import APIRouter, HTTPException\nfrom pydantic import BaseModel\nfrom typing import List\nimport uuid\nfrom datetime import datetime, timezone\n\nrouter = APIRouter(prefix=\"/api\")\n\nclass Item(BaseModel):\n    id: str\n    title: str\n    content: str\n    created_at: datetime\n    updated_at: datetime\n\n@router.post(\"/items\", response_model=Item)\nasync def create_item(title: str, content: str):\n    item = Item(\n        id=str(uuid.uuid4()),\n        title=title,\n        content=content,\n        created_at=datetime.now(timezone.utc),\n        updated_at=datetime.now(timezone.utc)\n    )\n    # Save to database\n    return item\n\n@router.get(\"/items\", response_model=List[Item])\nasync def list_items():\n    # Fetch from database\n    return []\n",
  "frontend/ItemList.js": "import React, { useState, useEffect } from 'react';\nimport axios from 'axios';\n\nconst ItemList = () => {\n  const [items, setItems] = useState([]);\n  \n  useEffect(() => {\n    fetchItems();\n  }, []);\n  \n  const fetchItems = async () => {\n    try {\n      const response = await axios.get('/api/items');\n      setItems(response.data);\n    } catch (error) {\n      console.error('Error fetching items:', error);\n    }\n  };\n  \n  return (\n    <div className=\"space-y-4\">\n      {items.map(item => (\n        <div key={item.id} className=\"p-4 border rounded-lg\">\n          <h3 className=\"font-bold\">{item.title}</h3>\n          <p>{item.content}</p>\n        </div>\n      ))}\n    </div>\n  );\n};\n\nexport default ItemList;"
}'''
    
    def _designer_simulation(self, prompt: str) -> str:
        return '''{
  "palette": {
    "primary": "#6366f1",
    "secondary": "#8b5cf6",
    "accent": "#ec4899",
    "background": "#0f172a",
    "foreground": "#f1f5f9",
    "muted": "#64748b"
  },
  "fonts": {
    "heading": "Space Grotesk",
    "body": "Inter",
    "mono": "JetBrains Mono"
  },
  "spacing": {
    "xs": "0.25rem",
    "sm": "0.5rem",
    "md": "1rem",
    "lg": "1.5rem",
    "xl": "2rem"
  },
  "components": [
    {
      "name": "Card",
      "props": "className, children",
      "description": "Glassmorphic card with backdrop blur"
    },
    {
      "name": "Button",
      "props": "variant, size, children, onClick",
      "description": "Pill-shaped button with hover animations"
    }
  ],
  "tailwind_theme": "module.exports = {\n  theme: {\n    extend: {\n      colors: {\n        primary: '#6366f1',\n        secondary: '#8b5cf6',\n        accent: '#ec4899'\n      }\n    }\n  }\n}"
}'''
    
    def _devops_simulation(self, prompt: str) -> str:
        return '''{
  "dockerfile": "FROM python:3.11-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install -r requirements.txt\nCOPY . .\nEXPOSE 8000\nCMD [\"uvicorn\", \"server:app\", \"--host\", \"0.0.0.0\", \"--port\", \"8000\"]",
  "docker_compose": "version: '3.8'\nservices:\n  backend:\n    build: ./backend\n    ports:\n      - 8000:8000\n  frontend:\n    build: ./frontend\n    ports:\n      - 3000:3000\n  mongodb:\n    image: mongo:7\n    ports:\n      - 27017:27017",
  "run_local_sh": "#!/bin/bash\necho 'Starting Emergent App...'\ndocker-compose up -d\necho 'App running at http://localhost:3000'",
  "readme": "# Generated Emergent App\n\n## Quick Start\n\n1. Install dependencies:\n   - Backend: `pip install -r requirements.txt`\n   - Frontend: `yarn install`\n\n2. Start services:\n   ```bash\n   ./run_local.sh\n   ```\n\n3. Access app at http://localhost:3000"
}'''
    
    def _critic_simulation(self, prompt: str) -> str:
        return '''{
  "issues": [
    {
      "severity": "low",
      "type": "security",
      "message": "Consider adding rate limiting to API endpoints",
      "fix": "Use slowapi or similar middleware"
    },
    {
      "severity": "medium",
      "type": "testing",
      "message": "No unit tests found",
      "fix": "Add pytest tests for core functionality"
    },
    {
      "severity": "low",
      "type": "ux",
      "message": "Loading states not implemented",
      "fix": "Add loading spinners for async operations"
    }
  ],
  "score": 85,
  "summary": "Good foundation. Add tests and security hardening."
}'''


# Global model instance
_model_loader = None

def get_model_loader() -> ModelLoader:
    """Get or create the global model loader instance"""
    global _model_loader
    if _model_loader is None:
        _model_loader = ModelLoader()
    return _model_loader
