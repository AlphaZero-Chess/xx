"""
WebSocket Handlers - Phase 3.4
Real-time communication for UI
"""

import json
import logging
import asyncio
from typing import Dict, Set, Optional
from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages WebSocket connections"""
    
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {
            "inspect": set(),
            "agents": set(),
            "memory": set(),
            "graph": set()
        }
        self.session_connections: Dict[str, Set[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, channel: str, session_id: Optional[str] = None):
        """Register a new connection"""
        await websocket.accept()
        
        if channel in self.active_connections:
            self.active_connections[channel].add(websocket)
        
        if session_id:
            if session_id not in self.session_connections:
                self.session_connections[session_id] = set()
            self.session_connections[session_id].add(websocket)
        
        logger.info(f"WebSocket connected to {channel}" + (f" session {session_id}" if session_id else ""))
    
    def disconnect(self, websocket: WebSocket, channel: str, session_id: Optional[str] = None):
        """Remove a connection"""
        if channel in self.active_connections:
            self.active_connections[channel].discard(websocket)
        
        if session_id and session_id in self.session_connections:
            self.session_connections[session_id].discard(websocket)
            if not self.session_connections[session_id]:
                del self.session_connections[session_id]
        
        logger.info(f"WebSocket disconnected from {channel}")
    
    async def broadcast(self, channel: str, message: dict):
        """Broadcast message to all connections on a channel"""
        if channel not in self.active_connections:
            return
        
        dead_connections = set()
        for connection in self.active_connections[channel]:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Failed to send to connection: {e}")
                dead_connections.add(connection)
        
        # Clean up dead connections
        for conn in dead_connections:
            self.active_connections[channel].discard(conn)
    
    async def send_to_session(self, session_id: str, message: dict):
        """Send message to all connections in a session"""
        if session_id not in self.session_connections:
            return
        
        dead_connections = set()
        for connection in self.session_connections[session_id]:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Failed to send to session connection: {e}")
                dead_connections.add(connection)
        
        # Clean up
        for conn in dead_connections:
            self.session_connections[session_id].discard(conn)
    
    async def send_personal(self, websocket: WebSocket, message: dict):
        """Send message to a specific connection"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Failed to send personal message: {e}")


class WebSocketEventBroker:
    """
    Event broker for pushing events to WebSocket clients
    Integrates with AgentBus, Memory, and TaskGraph
    """
    
    def __init__(self, connection_manager: ConnectionManager):
        self.manager = connection_manager
        self._running = False
        self._tasks = []
    
    async def start(self, agent_bus=None, reflective_memory=None, task_graph_manager=None):
        """Start event listeners"""
        self._running = True
        
        # Subscribe to agent bus if available
        if agent_bus:
            self._tasks.append(
                asyncio.create_task(self._listen_agent_bus(agent_bus))
            )
        
        logger.info("WebSocket event broker started")
    
    async def stop(self):
        """Stop event listeners"""
        self._running = False
        for task in self._tasks:
            task.cancel()
        logger.info("WebSocket event broker stopped")
    
    async def _listen_agent_bus(self, agent_bus):
        """Listen to agent bus and forward messages to WebSocket clients"""
        try:
            async def agent_message_callback(message):
                event = {
                    "type": "agent:message",
                    "data": message.to_dict()
                }
                await self.manager.broadcast("agents", event)
            
            # Subscribe to broadcast channel
            await agent_bus.subscribe("broadcast", agent_message_callback)
            
            # Keep listener alive
            while self._running:
                await asyncio.sleep(1)
                
        except Exception as e:
            logger.error(f"Agent bus listener error: {e}")
    
    async def emit_memory_update(self, agent_id: str, memory_data: dict):
        """Emit memory update event"""
        event = {
            "type": "memory:update",
            "data": {
                "agent_id": agent_id,
                "memory": memory_data
            }
        }
        await self.manager.broadcast("memory", event)
    
    async def emit_graph_update(self, graph_id: str, graph_data: dict):
        """Emit graph update event"""
        event = {
            "type": "graph:update",
            "data": {
                "graph_id": graph_id,
                "graph": graph_data
            }
        }
        await self.manager.broadcast("graph", event)
    
    async def emit_generation_log(self, session_id: str, log_data: dict):
        """Emit generation log event"""
        event = {
            "type": "generation:log",
            "data": log_data
        }
        await self.manager.send_to_session(session_id, event)
