import re
from typing import Dict, List

class IntentParser:
    """Parses user requests to extract intent, features, and vibes"""
    
    def __init__(self):
        self.vibe_keywords = [
            'calm', 'serene', 'peaceful', 'tranquil',
            'cosmic', 'space', 'celestial', 'stellar',
            'vibrant', 'energetic', 'dynamic', 'lively',
            'minimal', 'clean', 'simple', 'elegant',
            'playful', 'fun', 'cheerful', 'whimsical',
            'professional', 'corporate', 'business', 'formal',
            'dark', 'moody', 'atmospheric',
            'bright', 'light', 'airy',
            'retro', 'vintage', 'nostalgic',
            'futuristic', 'sci-fi', 'tech'
        ]
        
        self.feature_patterns = [
            r'with (.+?)(?:and|,|\.|$)',
            r'that (.+?)(?:and|,|\.|$)',
            r'including (.+?)(?:and|,|\.|$)',
        ]
    
    def parse(self, user_request: str) -> Dict:
        """Parse user request into structured intent"""
        result = {
            'type': self._detect_app_type(user_request),
            'features': self._extract_features(user_request),
            'vibes': self._extract_vibes(user_request),
            'keywords': self._extract_keywords(user_request)
        }
        return result
    
    def _detect_app_type(self, text: str) -> str:
        """Detect the type of application being requested"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['dashboard', 'analytics', 'metrics']):
            return 'dashboard'
        elif any(word in text_lower for word in ['chat', 'messaging', 'conversation']):
            return 'chat'
        elif any(word in text_lower for word in ['journal', 'diary', 'log']):
            return 'journal'
        elif any(word in text_lower for word in ['ecommerce', 'shop', 'store', 'marketplace']):
            return 'ecommerce'
        elif any(word in text_lower for word in ['blog', 'article', 'post']):
            return 'blog'
        elif any(word in text_lower for word in ['todo', 'task', 'project management']):
            return 'todo'
        elif any(word in text_lower for word in ['social', 'network', 'community']):
            return 'social'
        else:
            return 'general'
    
    def _extract_features(self, text: str) -> List[str]:
        """Extract feature requests from text"""
        features = []
        for pattern in self.feature_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            features.extend([m.strip() for m in matches])
        return features
    
    def _extract_vibes(self, text: str) -> str:
        """Extract vibe/aesthetic keywords"""
        text_lower = text.lower()
        found_vibes = []
        
        for vibe in self.vibe_keywords:
            if vibe in text_lower:
                found_vibes.append(vibe)
        
        return ', '.join(found_vibes)
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract key technical terms"""
        tech_keywords = [
            'ai', 'ml', 'api', 'real-time', 'database',
            'authentication', 'auth', 'login', 'signup',
            'payment', 'stripe', 'notifications',
            'search', 'filter', 'sort',
            'upload', 'download', 'export',
            'mobile', 'responsive', 'pwa'
        ]
        
        text_lower = text.lower()
        found = [kw for kw in tech_keywords if kw in text_lower]
        return found
