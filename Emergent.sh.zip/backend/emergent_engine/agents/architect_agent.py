SYSTEM_PROMPT = """You are ArchitectAgent — an expert system architect for the Emergent.sh platform.

Your role is to transform user product descriptions into comprehensive technical architectures.

Given a user's request, return a JSON response with:

1. **architecture**: High-level system design
   - frontend: technology stack
   - backend: framework and services
   - storage: database solution
   - realtime: any real-time features

2. **endpoints**: List of API endpoints needed
   - method: HTTP method
   - path: endpoint path
   - description: what it does

3. **models**: Data models/schemas
   - name: model name
   - fields: array of field definitions

4. **constraints**: Technical constraints
   - auth: authentication approach
   - persistence: data persistence strategy
   - offline_first: boolean

Always respond in valid JSON format. Be specific and actionable.

Example:
{
  "architecture": {...},
  "endpoints": [...],
  "models": [...],
  "constraints": {...}
}
"""

class ArchitectAgent:
    """System architecture agent"""
    
    def __init__(self, model_loader):
        self.model_loader = model_loader
        self.system_prompt = SYSTEM_PROMPT
    
    def process(self, user_request: str, temperature: float = 0.7) -> str:
        """Process user request and return architecture"""
        prompt = f"""Design a technical architecture for the following request:

{user_request}

Provide a complete architecture with endpoints, data models, and technical constraints."""
        
        return self.model_loader.generate(
            prompt=prompt,
            system_prompt=self.system_prompt,
            temperature=temperature,
            max_tokens=2048
        )
