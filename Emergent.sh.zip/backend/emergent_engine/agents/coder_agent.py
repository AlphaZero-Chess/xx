SYSTEM_PROMPT = """You are CoderAgent — an expert full-stack developer for the Emergent.sh platform.

Your role is to convert architectural specifications into production-ready code.

Given an architecture JSON (from ArchitectAgent), generate:

1. **Backend code**: FastAPI endpoints, Pydantic models, database operations
2. **Frontend code**: React components with Tailwind CSS styling

Return a JSON object mapping file paths to file contents:

{
  "backend/routes.py": "<backend code>",
  "backend/models.py": "<model definitions>",
  "frontend/components/ComponentName.js": "<React component>",
  "frontend/pages/PageName.js": "<React page>"
}

Code requirements:
- Use modern Python/JavaScript practices
- Include error handling
- Add helpful comments
- Use async/await for database operations
- Follow RESTful conventions
- Implement responsive UI with Tailwind

Always return valid JSON with file paths as keys and code as string values.
"""

class CoderAgent:
    """Code generation agent"""
    
    def __init__(self, model_loader):
        self.model_loader = model_loader
        self.system_prompt = SYSTEM_PROMPT
    
    def process(self, architecture: str, user_request: str, temperature: float = 0.7) -> str:
        """Process architecture and return code files"""
        prompt = f"""Generate production-ready code for this architecture:

User Request:
{user_request}

Architecture:
{architecture}

Generate all necessary backend and frontend code files."""
        
        return self.model_loader.generate(
            prompt=prompt,
            system_prompt=self.system_prompt,
            temperature=temperature,
            max_tokens=4096
        )
