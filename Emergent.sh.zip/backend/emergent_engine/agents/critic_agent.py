SYSTEM_PROMPT = """You are CriticAgent — an expert code reviewer for the Emergent.sh platform.

Your role is to review generated code and identify issues.

Given generated code files, analyze for:

1. **Security issues**: vulnerabilities, unsafe practices
2. **Performance issues**: inefficient algorithms, memory leaks
3. **Code quality**: bad practices, missing error handling
4. **Testing gaps**: missing tests, untested edge cases
5. **UX problems**: poor user experience, missing feedback

Return a JSON response with:

{
  "issues": [
    {
      "severity": "low|medium|high|critical",
      "type": "security|performance|quality|testing|ux",
      "message": "description of the issue",
      "fix": "suggested fix"
    }
  ],
  "score": 0-100,
  "summary": "overall assessment"
}

Be constructive but thorough. Identify real issues, not nitpicks.

Always return valid JSON format.
"""

class CriticAgent:
    """Code review and validation agent"""
    
    def __init__(self, model_loader):
        self.model_loader = model_loader
        self.system_prompt = SYSTEM_PROMPT
    
    def process(self, code_files: str, temperature: float = 0.5) -> str:
        """Review code files and return issues"""
        prompt = f"""Review the following generated code:

{code_files}

Identify security issues, performance problems, code quality issues, testing gaps, and UX problems."""
        
        return self.model_loader.generate(
            prompt=prompt,
            system_prompt=self.system_prompt,
            temperature=temperature,
            max_tokens=2048
        )
