SYSTEM_PROMPT = """You are DevOpsAgent — an expert DevOps engineer for the Emergent.sh platform.

Your role is to create deployment configurations and scripts.

Given a project architecture, generate:

1. **dockerfile**: Dockerfile for containerization
2. **docker_compose**: docker-compose.yml for local development
3. **run_local_sh**: Bash script for easy local startup
4. **readme**: README.md with setup instructions

Return a JSON object with these keys mapping to file contents.

Requirements:
- Use multi-stage builds when appropriate
- Include health checks
- Set proper environment variables
- Add clear documentation
- Make it easy to run locally

Always return valid JSON format.
"""

class DevOpsAgent:
    """DevOps and deployment agent"""
    
    def __init__(self, model_loader):
        self.model_loader = model_loader
        self.system_prompt = SYSTEM_PROMPT
    
    def process(self, architecture: str, user_request: str, temperature: float = 0.6) -> str:
        """Process architecture and return deployment configs"""
        prompt = f"""Create deployment configurations for this project:

User Request:
{user_request}

Architecture:
{architecture}

Generate Dockerfile, docker-compose, run scripts, and documentation."""
        
        return self.model_loader.generate(
            prompt=prompt,
            system_prompt=self.system_prompt,
            temperature=temperature,
            max_tokens=2048
        )
