"""
Redis Memory Adapter for Phase 2
Fast ephemeral memory for agents with MongoDB persistence
"""

import logging
import json
import os
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone, timedelta
import redis
from redis.exceptions import RedisError

logger = logging.getLogger(__name__)


class RedisMemoryAdapter:
    """Redis adapter for fast agent memory with TTL support"""
    
    def __init__(self):
        """Initialize Redis connection"""
        self.redis_url = os.environ.get('REDIS_URL', 'redis://localhost:6379')
        self.client: Optional[redis.Redis] = None
        self.connected = False
        
        try:
            self.client = redis.from_url(
                self.redis_url,
                decode_responses=True,
                socket_timeout=5,
                socket_connect_timeout=5
            )
            # Test connection
            self.client.ping()
            self.connected = True
            logger.info("Redis connected successfully")
        except RedisError as e:
            logger.warning(f"Redis unavailable: {e}. Operating without Redis cache.")
            self.connected = False
    
    def remember(self, key: str, content: Any, ttl: Optional[int] = None, 
                 namespace: str = "emergent") -> bool:
        """
        Store data in Redis with optional TTL
        
        Args:
            key: Memory key
            content: Data to store (will be JSON serialized)
            ttl: Time to live in seconds (None = no expiry)
            namespace: Key namespace/prefix
        
        Returns:
            Success status
        """
        if not self.connected:
            return False
        
        try:
            full_key = f"{namespace}:{key}"
            
            # Serialize content
            if isinstance(content, (dict, list)):
                value = json.dumps(content)
            else:
                value = str(content)
            
            # Store with optional TTL
            if ttl:
                self.client.setex(full_key, ttl, value)
            else:
                self.client.set(full_key, value)
            
            logger.debug(f"Stored memory: {full_key}")
            return True
            
        except RedisError as e:
            logger.error(f"Failed to store memory {key}: {e}")
            return False
    
    def recall(self, key: str, namespace: str = "emergent") -> Optional[Any]:
        """
        Retrieve data from Redis
        
        Args:
            key: Memory key
            namespace: Key namespace/prefix
        
        Returns:
            Stored data or None if not found
        """
        if not self.connected:
            return None
        
        try:
            full_key = f"{namespace}:{key}"
            value = self.client.get(full_key)
            
            if value is None:
                return None
            
            # Try to deserialize JSON
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return value
                
        except RedisError as e:
            logger.error(f"Failed to recall memory {key}: {e}")
            return None
    
    def forget(self, key: str, namespace: str = "emergent") -> bool:
        """
        Delete data from Redis
        
        Args:
            key: Memory key
            namespace: Key namespace/prefix
        
        Returns:
            Success status
        """
        if not self.connected:
            return False
        
        try:
            full_key = f"{namespace}:{key}"
            self.client.delete(full_key)
            logger.debug(f"Deleted memory: {full_key}")
            return True
            
        except RedisError as e:
            logger.error(f"Failed to delete memory {key}: {e}")
            return False
    
    def search_keys(self, pattern: str, namespace: str = "emergent") -> List[str]:
        """
        Search for keys matching pattern
        
        Args:
            pattern: Redis key pattern (e.g., "agent:*")
            namespace: Key namespace/prefix
        
        Returns:
            List of matching keys (without namespace prefix)
        """
        if not self.connected:
            return []
        
        try:
            full_pattern = f"{namespace}:{pattern}"
            keys = self.client.keys(full_pattern)
            
            # Remove namespace prefix
            prefix_len = len(f"{namespace}:")
            return [key[prefix_len:] for key in keys]
            
        except RedisError as e:
            logger.error(f"Failed to search keys {pattern}: {e}")
            return []
    
    def increment(self, key: str, amount: int = 1, 
                  namespace: str = "emergent") -> Optional[int]:
        """
        Increment a counter
        
        Args:
            key: Counter key
            amount: Amount to increment by
            namespace: Key namespace/prefix
        
        Returns:
            New value or None on error
        """
        if not self.connected:
            return None
        
        try:
            full_key = f"{namespace}:{key}"
            return self.client.incrby(full_key, amount)
            
        except RedisError as e:
            logger.error(f"Failed to increment {key}: {e}")
            return None
    
    def get_ttl(self, key: str, namespace: str = "emergent") -> Optional[int]:
        """
        Get remaining TTL for a key
        
        Args:
            key: Memory key
            namespace: Key namespace/prefix
        
        Returns:
            Remaining TTL in seconds, -1 if no TTL, -2 if key doesn't exist
        """
        if not self.connected:
            return None
        
        try:
            full_key = f"{namespace}:{key}"
            return self.client.ttl(full_key)
            
        except RedisError as e:
            logger.error(f"Failed to get TTL for {key}: {e}")
            return None
    
    def publish(self, channel: str, message: Any) -> bool:
        """
        Publish message to Redis pub/sub channel
        
        Args:
            channel: Channel name
            message: Message to publish (will be JSON serialized)
        
        Returns:
            Success status
        """
        if not self.connected:
            return False
        
        try:
            if isinstance(message, (dict, list)):
                payload = json.dumps(message)
            else:
                payload = str(message)
            
            self.client.publish(channel, payload)
            logger.debug(f"Published to channel {channel}")
            return True
            
        except RedisError as e:
            logger.error(f"Failed to publish to {channel}: {e}")
            return False
    
    def is_connected(self) -> bool:
        """Check if Redis is connected"""
        return self.connected
    
    def flush_namespace(self, namespace: str = "emergent") -> bool:
        """
        Delete all keys in a namespace
        
        Args:
            namespace: Namespace to flush
        
        Returns:
            Success status
        """
        if not self.connected:
            return False
        
        try:
            pattern = f"{namespace}:*"
            keys = self.client.keys(pattern)
            
            if keys:
                self.client.delete(*keys)
                logger.info(f"Flushed {len(keys)} keys from namespace {namespace}")
            
            return True
            
        except RedisError as e:
            logger.error(f"Failed to flush namespace {namespace}: {e}")
            return False


class MemoryStore:
    """
    Unified memory store with Redis cache + MongoDB persistence
    Provides a simple interface for agent memory management
    """
    
    def __init__(self, redis_adapter: RedisMemoryAdapter, mongo_db=None):
        """
        Initialize memory store
        
        Args:
            redis_adapter: Redis adapter for fast cache
            mongo_db: MongoDB database for persistence (optional)
        """
        self.redis = redis_adapter
        self.db = mongo_db
        self.persistence_enabled = mongo_db is not None
    
    async def remember(self, agent_id: str, key: str, content: Any, 
                       ttl: Optional[int] = 3600, persist: bool = False) -> bool:
        """
        Store memory with optional persistence
        
        Args:
            agent_id: Agent identifier
            key: Memory key
            content: Data to store
            ttl: Cache TTL in seconds (default 1 hour)
            persist: Whether to persist to MongoDB
        
        Returns:
            Success status
        """
        memory_key = f"agent:{agent_id}:{key}"
        
        # Store in Redis cache
        success = self.redis.remember(memory_key, content, ttl=ttl)
        
        # Optionally persist to MongoDB
        if persist and self.persistence_enabled:
            try:
                memory_doc = {
                    "agent_id": agent_id,
                    "key": key,
                    "content": content,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "ttl": ttl
                }
                await self.db.agent_memory.update_one(
                    {"agent_id": agent_id, "key": key},
                    {"$set": memory_doc},
                    upsert=True
                )
                logger.debug(f"Persisted memory to MongoDB: {agent_id}:{key}")
            except Exception as e:
                logger.error(f"Failed to persist memory: {e}")
        
        return success
    
    def recall(self, agent_id: str, key: str) -> Optional[Any]:
        """
        Retrieve memory from cache
        
        Args:
            agent_id: Agent identifier
            key: Memory key
        
        Returns:
            Stored data or None
        """
        memory_key = f"agent:{agent_id}:{key}"
        return self.redis.recall(memory_key)
    
    async def recall_or_load(self, agent_id: str, key: str) -> Optional[Any]:
        """
        Retrieve from cache, or load from MongoDB if not cached
        
        Args:
            agent_id: Agent identifier
            key: Memory key
        
        Returns:
            Stored data or None
        """
        # Try cache first
        cached = self.recall(agent_id, key)
        if cached is not None:
            return cached
        
        # Load from MongoDB
        if self.persistence_enabled:
            try:
                doc = await self.db.agent_memory.find_one(
                    {"agent_id": agent_id, "key": key}
                )
                if doc:
                    content = doc['content']
                    # Restore to cache
                    ttl = doc.get('ttl', 3600)
                    self.redis.remember(f"agent:{agent_id}:{key}", content, ttl=ttl)
                    return content
            except Exception as e:
                logger.error(f"Failed to load memory from MongoDB: {e}")
        
        return None
    
    async def get_agent_history(self, agent_id: str, limit: int = 100) -> List[Dict]:
        """
        Get agent's memory history from MongoDB
        
        Args:
            agent_id: Agent identifier
            limit: Maximum number of records
        
        Returns:
            List of memory records
        """
        if not self.persistence_enabled:
            return []
        
        try:
            cursor = self.db.agent_memory.find(
                {"agent_id": agent_id}
            ).sort("created_at", -1).limit(limit)
            
            return await cursor.to_list(length=limit)
        except Exception as e:
            logger.error(f"Failed to get agent history: {e}")
            return []
    
    def forget(self, agent_id: str, key: str) -> bool:
        """
        Delete memory from cache
        
        Args:
            agent_id: Agent identifier
            key: Memory key
        
        Returns:
            Success status
        """
        memory_key = f"agent:{agent_id}:{key}"
        return self.redis.forget(memory_key)
    
    def publish_event(self, channel: str, event: Dict[str, Any]) -> bool:
        """
        Publish event to Redis pub/sub
        
        Args:
            channel: Channel name
            event: Event data
        
        Returns:
            Success status
        """
        return self.redis.publish(channel, event)
