"""
Reflective Memory Layer for Phase 2.1
Provides semantic memory with embeddings for intelligent agent recall
"""

import logging
import json
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime, timezone
import numpy as np

logger = logging.getLogger(__name__)


class EmbeddingEngine:
    """Handles text embeddings for semantic search"""
    
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize embedding engine
        
        Args:
            model_name: SentenceTransformers model name (lightweight by default)
        """
        self.model = None
        self.model_name = model_name
        self._load_model()
    
    def _load_model(self):
        """Load the embedding model"""
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(self.model_name)
            logger.info(f"Embedding model loaded: {self.model_name}")
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")
            self.model = None
    
    def embed(self, text: str) -> Optional[np.ndarray]:
        """
        Generate embedding for text
        
        Args:
            text: Input text
        
        Returns:
            Embedding vector or None on error
        """
        if self.model is None:
            logger.warning("Embedding model not available")
            return None
        
        try:
            embedding = self.model.encode(text, convert_to_numpy=True)
            return embedding
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            return None
    
    def embed_batch(self, texts: List[str]) -> Optional[np.ndarray]:
        """
        Generate embeddings for multiple texts
        
        Args:
            texts: List of input texts
        
        Returns:
            Array of embeddings or None on error
        """
        if self.model is None:
            logger.warning("Embedding model not available")
            return None
        
        try:
            embeddings = self.model.encode(texts, convert_to_numpy=True)
            return embeddings
        except Exception as e:
            logger.error(f"Batch embedding failed: {e}")
            return None
    
    def similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """
        Calculate cosine similarity between embeddings
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
        
        Returns:
            Similarity score (0-1)
        """
        try:
            return float(np.dot(embedding1, embedding2) / 
                        (np.linalg.norm(embedding1) * np.linalg.norm(embedding2)))
        except Exception as e:
            logger.error(f"Similarity calculation failed: {e}")
            return 0.0


class ReflectiveMemory:
    """
    Reflective memory system for agents
    Combines Redis cache, MongoDB persistence, and semantic search
    """
    
    def __init__(self, memory_store, embedding_engine: Optional[EmbeddingEngine] = None):
        """
        Initialize reflective memory
        
        Args:
            memory_store: MemoryStore instance (Redis + MongoDB)
            embedding_engine: EmbeddingEngine for semantic search
        """
        self.store = memory_store
        self.embedder = embedding_engine or EmbeddingEngine()
        self.session_context: Dict[str, List[Dict]] = {}
    
    async def remember(self, agent_id: str, content: str, 
                       metadata: Optional[Dict] = None,
                       importance: float = 0.5,
                       persist: bool = False) -> bool:
        """
        Store a memory with semantic embedding
        
        Args:
            agent_id: Agent identifier
            content: Memory content (text)
            metadata: Additional metadata
            importance: Importance score (0-1)
            persist: Whether to persist to MongoDB
        
        Returns:
            Success status
        """
        try:
            # Generate embedding
            embedding = self.embedder.embed(content)
            if embedding is None:
                logger.warning("Embedding failed, storing without semantic search capability")
                embedding_list = []
            else:
                embedding_list = embedding.tolist()
            
            # Create memory object
            memory = {
                "content": content,
                "embedding": embedding_list,
                "metadata": metadata or {},
                "importance": importance,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "access_count": 0
            }
            
            # Generate unique key
            timestamp_key = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            key = f"memory:{timestamp_key}"
            
            # Store in memory store
            ttl = 86400 if importance > 0.7 else 3600  # High importance = longer TTL
            success = await self.store.remember(agent_id, key, memory, ttl=ttl, persist=persist)
            
            # Update session context
            if agent_id not in self.session_context:
                self.session_context[agent_id] = []
            self.session_context[agent_id].append({
                "key": key,
                "content": content,
                "timestamp": memory["timestamp"]
            })
            
            logger.debug(f"Memory stored for {agent_id}: {key}")
            return success
            
        except Exception as e:
            logger.error(f"Failed to store memory: {e}")
            return False
    
    async def recall(self, agent_id: str, query: str, 
                     top_k: int = 5,
                     min_similarity: float = 0.3) -> List[Dict]:
        """
        Semantic search for relevant memories
        
        Args:
            agent_id: Agent identifier
            query: Search query
            top_k: Number of results to return
            min_similarity: Minimum similarity threshold
        
        Returns:
            List of relevant memories with similarity scores
        """
        try:
            # Generate query embedding
            query_embedding = self.embedder.embed(query)
            if query_embedding is None:
                logger.warning("Query embedding failed, returning empty results")
                return []
            
            # Get all agent memories from session context
            if agent_id not in self.session_context:
                logger.debug(f"No session context for {agent_id}")
                return []
            
            # Load memories and calculate similarities
            results = []
            for item in self.session_context[agent_id]:
                memory = await self.store.recall_or_load(agent_id, item["key"])
                if memory and memory.get("embedding"):
                    memory_embedding = np.array(memory["embedding"])
                    similarity = self.embedder.similarity(query_embedding, memory_embedding)
                    
                    if similarity >= min_similarity:
                        results.append({
                            "content": memory["content"],
                            "similarity": similarity,
                            "metadata": memory.get("metadata", {}),
                            "importance": memory.get("importance", 0.5),
                            "timestamp": memory.get("timestamp"),
                            "key": item["key"]
                        })
            
            # Sort by similarity and importance
            results.sort(key=lambda x: (x["similarity"] * 0.7 + x["importance"] * 0.3), 
                        reverse=True)
            
            # Update access counts
            for result in results[:top_k]:
                memory = await self.store.recall_or_load(agent_id, result["key"])
                if memory:
                    memory["access_count"] = memory.get("access_count", 0) + 1
                    await self.store.remember(agent_id, result["key"], memory, persist=False)
            
            logger.debug(f"Found {len(results[:top_k])} relevant memories for query: {query}")
            return results[:top_k]
            
        except Exception as e:
            logger.error(f"Memory recall failed: {e}")
            return []
    
    async def summarize_context(self, agent_id: str, max_items: int = 20) -> str:
        """
        Summarize recent session context for an agent
        
        Args:
            agent_id: Agent identifier
            max_items: Maximum number of recent items to include
        
        Returns:
            Context summary as text
        """
        if agent_id not in self.session_context:
            return "No context available."
        
        recent_context = self.session_context[agent_id][-max_items:]
        
        summary_lines = [f"Recent context for {agent_id}:"]
        for idx, item in enumerate(recent_context, 1):
            summary_lines.append(f"{idx}. {item['content'][:100]}...")
        
        return "\n".join(summary_lines)
    
    async def get_important_memories(self, agent_id: str, 
                                     threshold: float = 0.7,
                                     limit: int = 10) -> List[Dict]:
        """
        Get high-importance memories for an agent
        
        Args:
            agent_id: Agent identifier
            threshold: Minimum importance threshold
            limit: Maximum number of results
        
        Returns:
            List of important memories
        """
        if agent_id not in self.session_context:
            return []
        
        important = []
        for item in self.session_context[agent_id]:
            memory = await self.store.recall_or_load(agent_id, item["key"])
            if memory and memory.get("importance", 0) >= threshold:
                important.append({
                    "content": memory["content"],
                    "importance": memory["importance"],
                    "timestamp": memory["timestamp"],
                    "access_count": memory.get("access_count", 0)
                })
        
        # Sort by importance and access count
        important.sort(
            key=lambda x: (x["importance"] * 0.6 + min(x["access_count"] / 10, 0.4)), 
            reverse=True
        )
        
        return important[:limit]
    
    def clear_session(self, agent_id: str):
        """
        Clear session context for an agent
        
        Args:
            agent_id: Agent identifier
        """
        if agent_id in self.session_context:
            del self.session_context[agent_id]
            logger.info(f"Cleared session context for {agent_id}")
    
    async def reflect(self, agent_id: str, topic: str) -> Optional[str]:
        """
        Generate a reflection based on memories about a topic
        
        Args:
            agent_id: Agent identifier
            topic: Topic to reflect on
        
        Returns:
            Reflection text or None
        """
        # Recall relevant memories
        memories = await self.recall(agent_id, topic, top_k=5)
        
        if not memories:
            return f"No significant memories found about: {topic}"
        
        # Build reflection
        reflection_parts = [f"Reflecting on '{topic}':"]
        for i, mem in enumerate(memories, 1):
            reflection_parts.append(
                f"\n{i}. (Relevance: {mem['similarity']:.2f}) {mem['content']}"
            )
        
        return "\n".join(reflection_parts)
