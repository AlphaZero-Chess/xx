import json
import logging
from typing import Dict, Any
import uuid
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class ProjectSynthesizer:
    """Synthesizes agent outputs into a complete project structure"""
    
    def synthesize(self, user_request: str, architecture: str, 
                   design: str, code: str, devops: str, critique: str) -> Dict[str, Any]:
        """Combine all agent outputs into a project"""
        try:
            project_id = str(uuid.uuid4())
            
            # Parse JSON outputs
            arch_data = self._safe_parse(architecture)
            design_data = self._safe_parse(design)
            code_data = self._safe_parse(code)
            devops_data = self._safe_parse(devops)
            critique_data = self._safe_parse(critique)
            
            # Build project structure
            project = {
                'id': project_id,
                'name': self._generate_project_name(user_request),
                'description': user_request,
                'created_at': datetime.now(timezone.utc).isoformat(),
                'architecture': arch_data,
                'design': design_data,
                'files': code_data,
                'deployment': devops_data,
                'critique': critique_data,
                'status': 'generated'
            }
            
            logger.info(f"Project synthesized: {project_id}")
            return project
            
        except Exception as e:
            logger.error(f"Synthesis failed: {str(e)}")
            return {
                'id': str(uuid.uuid4()),
                'name': 'Untitled Project',
                'description': user_request,
                'created_at': datetime.now(timezone.utc).isoformat(),
                'error': str(e),
                'status': 'failed'
            }
    
    def _safe_parse(self, json_string: str) -> Dict:
        """Safely parse JSON string"""
        if not json_string:
            return {}
        
        try:
            # Try to find JSON in the string
            start = json_string.find('{')
            end = json_string.rfind('}') + 1
            
            if start >= 0 and end > start:
                json_part = json_string[start:end]
                return json.loads(json_part)
            
            return {}
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse failed: {str(e)}")
            return {'raw': json_string}
    
    def _generate_project_name(self, user_request: str) -> str:
        """Generate a project name from user request"""
        # Take first few words and slugify
        words = user_request.split()[:4]
        name = '-'.join(w.lower() for w in words if w.isalnum())
        return name[:50] if name else 'emergent-project'
