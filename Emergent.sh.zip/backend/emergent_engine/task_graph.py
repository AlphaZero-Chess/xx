"""
Task Graph Manager - Phase 3.2
DAG-based task planning and execution
"""

import json
import logging
import uuid
from typing import Dict, Any, List, Optional, Set
from datetime import datetime, timezone
from enum import Enum
import asyncio

logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class TaskNode:
    """Represents a single task in the execution graph"""
    
    def __init__(self,
                 task_id: str,
                 role: str,
                 action: str,
                 params: Dict[str, Any],
                 deps: Optional[List[str]] = None):
        self.task_id = task_id
        self.role = role
        self.action = action
        self.params = params
        self.deps = deps or []
        self.status = TaskStatus.PENDING
        self.result: Optional[Any] = None
        self.error: Optional[str] = None
        self.started_at: Optional[str] = None
        self.completed_at: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "role": self.role,
            "action": self.action,
            "params": self.params,
            "deps": self.deps,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskNode':
        node = cls(
            task_id=data['task_id'],
            role=data['role'],
            action=data['action'],
            params=data['params'],
            deps=data.get('deps', [])
        )
        node.status = data.get('status', TaskStatus.PENDING)
        node.result = data.get('result')
        node.error = data.get('error')
        node.started_at = data.get('started_at')
        node.completed_at = data.get('completed_at')
        return node


class TaskGraph:
    """DAG-based task execution graph"""
    
    def __init__(self, graph_id: Optional[str] = None):
        self.graph_id = graph_id or f"graph-{uuid.uuid4().hex[:8]}"
        self.nodes: Dict[str, TaskNode] = {}
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.status = "pending"
    
    def add_node(self, node: TaskNode) -> bool:
        """Add a task node to the graph"""
        if node.task_id in self.nodes:
            logger.warning(f"Task {node.task_id} already exists")
            return False
        
        self.nodes[node.task_id] = node
        return True
    
    def validate(self) -> bool:
        """Validate graph for cycles and invalid dependencies"""
        # Check for invalid dependencies
        for task_id, node in self.nodes.items():
            for dep in node.deps:
                if dep not in self.nodes:
                    logger.error(f"Invalid dependency: {dep} not in graph")
                    return False
        
        # Check for cycles using DFS
        visited = set()
        rec_stack = set()
        
        def has_cycle(task_id: str) -> bool:
            visited.add(task_id)
            rec_stack.add(task_id)
            
            for dep in self.nodes[task_id].deps:
                if dep not in visited:
                    if has_cycle(dep):
                        return True
                elif dep in rec_stack:
                    logger.error(f"Cycle detected at {task_id}")
                    return True
            
            rec_stack.remove(task_id)
            return False
        
        for task_id in self.nodes:
            if task_id not in visited:
                if has_cycle(task_id):
                    return False
        
        return True
    
    def get_ready_tasks(self) -> List[TaskNode]:
        """Get tasks that are ready to execute (all deps completed)"""
        ready = []
        
        for task_id, node in self.nodes.items():
            if node.status != TaskStatus.PENDING:
                continue
            
            # Check if all dependencies are completed
            deps_ready = all(
                self.nodes[dep].status == TaskStatus.COMPLETED
                for dep in node.deps
            )
            
            if deps_ready:
                ready.append(node)
        
        return ready
    
    def get_adjacency_list(self) -> Dict[str, List[str]]:
        """Get adjacency list representation of graph"""
        return {task_id: node.deps for task_id, node in self.nodes.items()}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "graph_id": self.graph_id,
            "created_at": self.created_at,
            "status": self.status,
            "nodes": {task_id: node.to_dict() for task_id, node in self.nodes.items()},
            "adjacency_list": self.get_adjacency_list()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskGraph':
        graph = cls(graph_id=data['graph_id'])
        graph.created_at = data['created_at']
        graph.status = data.get('status', 'pending')
        
        for task_id, node_data in data['nodes'].items():
            graph.nodes[task_id] = TaskNode.from_dict(node_data)
        
        return graph


class TaskGraphManager:
    """Manages task graph execution and persistence"""
    
    def __init__(self, agent_bus=None, db=None):
        self.agent_bus = agent_bus
        self.db = db
        self.graphs: Dict[str, TaskGraph] = {}
    
    async def create_graph(self, tasks: List[Dict[str, Any]]) -> Optional[TaskGraph]:
        """
        Create a new task graph from task definitions
        
        Args:
            tasks: List of task definitions
        
        Returns:
            TaskGraph instance or None on error
        """
        try:
            graph = TaskGraph()
            
            # Add all nodes
            for task_data in tasks:
                node = TaskNode(
                    task_id=task_data['task_id'],
                    role=task_data['role'],
                    action=task_data['action'],
                    params=task_data['params'],
                    deps=task_data.get('deps', [])
                )
                graph.add_node(node)
            
            # Validate graph
            if not graph.validate():
                logger.error("Graph validation failed")
                return None
            
            # Store graph
            self.graphs[graph.graph_id] = graph
            
            # Persist to MongoDB
            if self.db is not None:
                await self.db.task_graphs.insert_one(graph.to_dict())
            
            logger.info(f"Created task graph {graph.graph_id} with {len(tasks)} tasks")
            return graph
            
        except Exception as e:
            logger.error(f"Failed to create graph: {e}")
            return None
    
    async def execute_graph(self, graph_id: str) -> bool:
        """
        Execute a task graph
        
        Args:
            graph_id: Graph identifier
        
        Returns:
            Success status
        """
        if graph_id not in self.graphs:
            logger.error(f"Graph {graph_id} not found")
            return False
        
        graph = self.graphs[graph_id]
        graph.status = "running"
        
        try:
            while True:
                ready_tasks = graph.get_ready_tasks()
                
                if not ready_tasks:
                    # Check if all tasks completed
                    all_completed = all(
                        node.status == TaskStatus.COMPLETED
                        for node in graph.nodes.values()
                    )
                    
                    if all_completed:
                        graph.status = "completed"
                        logger.info(f"Graph {graph_id} completed successfully")
                        await self._persist_graph(graph)
                        return True
                    else:
                        # Some tasks failed or blocked
                        graph.status = "failed"
                        logger.error(f"Graph {graph_id} execution failed")
                        await self._persist_graph(graph)
                        return False
                
                # Execute ready tasks
                for task in ready_tasks:
                    await self._execute_task(graph, task)
                
                # Small delay to avoid tight loop
                await asyncio.sleep(0.1)
                
        except Exception as e:
            logger.error(f"Graph execution error: {e}")
            graph.status = "failed"
            await self._persist_graph(graph)
            return False
    
    async def _execute_task(self, graph: TaskGraph, task: TaskNode):
        """Execute a single task"""
        try:
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.now(timezone.utc).isoformat()
            
            logger.info(f"Executing task {task.task_id} (role: {task.role}, action: {task.action})")
            
            # Send message to agent via bus
            if self.agent_bus:
                from .agent_bus import Message
                message = Message(
                    from_agent="task_graph",
                    to_agent=task.role,
                    msg_type="task_execute",
                    payload={
                        "graph_id": graph.graph_id,
                        "task_id": task.task_id,
                        "action": task.action,
                        "params": task.params
                    }
                )
                await self.agent_bus.publish(message)
            
            # Simulated execution (replace with actual agent execution)
            await asyncio.sleep(0.5)
            
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.now(timezone.utc).isoformat()
            task.result = {"status": "success", "message": f"Task {task.task_id} completed"}
            
            logger.info(f"Task {task.task_id} completed")
            
        except Exception as e:
            logger.error(f"Task {task.task_id} failed: {e}")
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = datetime.now(timezone.utc).isoformat()
    
    async def _persist_graph(self, graph: TaskGraph):
        """Persist graph state to MongoDB"""
        if self.db is None:
            return
        
        try:
            await self.db.task_graphs.update_one(
                {"graph_id": graph.graph_id},
                {"$set": graph.to_dict()},
                upsert=True
            )
        except Exception as e:
            logger.error(f"Failed to persist graph: {e}")
    
    async def get_graph(self, graph_id: str) -> Optional[TaskGraph]:
        """Retrieve a graph by ID"""
        if graph_id in self.graphs:
            return self.graphs[graph_id]
        
        # Try loading from DB
        if self.db is not None:
            try:
                doc = await self.db.task_graphs.find_one({"graph_id": graph_id})
                if doc:
                    graph = TaskGraph.from_dict(doc)
                    self.graphs[graph_id] = graph
                    return graph
            except Exception as e:
                logger.error(f"Failed to load graph: {e}")
        
        return None
