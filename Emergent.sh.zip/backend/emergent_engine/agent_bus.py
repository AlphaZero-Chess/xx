"""
Agent Bus - Phase 3.1
Redis pub/sub based inter-agent messaging system
"""

import json
import asyncio
import logging
import os
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime, timezone
import uuid
from redis.asyncio import Redis
from redis.exceptions import RedisError

logger = logging.getLogger(__name__)


class Message:
    """Structured message envelope for agent communication"""
    
    def __init__(self, 
                 from_agent: str,
                 to_agent: str,
                 msg_type: str,
                 payload: Dict[str, Any],
                 trace_id: Optional[str] = None,
                 ttl: int = 300):
        self.id = f"msg-{uuid.uuid4().hex[:8]}"
        self.from_agent = from_agent
        self.to_agent = to_agent
        self.msg_type = msg_type
        self.payload = payload
        self.trace_id = trace_id or f"trace-{uuid.uuid4().hex[:8]}"
        self.ttl = ttl
        self.timestamp = datetime.now(timezone.utc).isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "from": self.from_agent,
            "to": self.to_agent,
            "type": self.msg_type,
            "payload": self.payload,
            "trace_id": self.trace_id,
            "ttl": self.ttl,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        msg = cls(
            from_agent=data['from'],
            to_agent=data['to'],
            msg_type=data['type'],
            payload=data['payload'],
            trace_id=data.get('trace_id'),
            ttl=data.get('ttl', 300)
        )
        msg.id = data['id']
        msg.timestamp = data['timestamp']
        return msg


class AgentBus:
    """
    Agent Bus for inter-agent communication
    Uses Redis pub/sub for real-time messaging
    Logs all messages for auditing and debugging
    """
    
    def __init__(self, db=None):
        self.redis_url = os.environ.get('REDIS_URL', 'redis://localhost:6379')
        self.redis: Optional[Redis] = None
        self.db = db
        self.connected = False
        self.subscribers: Dict[str, List[Callable]] = {}
        self._pubsub = None
        self._listen_task = None
    
    async def connect(self):
        """Initialize Redis connection"""
        try:
            self.redis = Redis.from_url(
                self.redis_url,
                decode_responses=True,
                socket_timeout=5,
                socket_connect_timeout=5
            )
            await self.redis.ping()
            self.connected = True
            logger.info("AgentBus connected to Redis")
        except Exception as e:
            logger.error(f"AgentBus failed to connect: {e}")
            self.connected = False
    
    async def publish(self, message: Message) -> bool:
        """
        Publish message to agent's inbox channel
        
        Args:
            message: Message to publish
        
        Returns:
            Success status
        """
        if not self.connected:
            logger.warning("AgentBus not connected, message not sent")
            return False
        
        try:
            channel = f"agent:{message.to_agent}:inbox"
            msg_json = json.dumps(message.to_dict())
            
            # Publish to Redis
            await self.redis.publish(channel, msg_json)
            
            # Log to event store
            await self._log_message(message)
            
            logger.debug(f"Message {message.id} published to {channel}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to publish message: {e}")
            return False
    
    async def broadcast(self, message: Message) -> bool:
        """
        Broadcast message to all agents
        
        Args:
            message: Message to broadcast
        
        Returns:
            Success status
        """
        if not self.connected:
            return False
        
        try:
            channel = "agent:broadcast"
            msg_json = json.dumps(message.to_dict())
            await self.redis.publish(channel, msg_json)
            await self._log_message(message)
            logger.debug(f"Message {message.id} broadcast")
            return True
        except Exception as e:
            logger.error(f"Failed to broadcast: {e}")
            return False
    
    async def subscribe(self, agent_id: str, callback: Callable) -> bool:
        """
        Subscribe to messages for a specific agent
        
        Args:
            agent_id: Agent identifier
            callback: Async function to call when message received
        
        Returns:
            Success status
        """
        if not self.connected:
            return False
        
        try:
            if agent_id not in self.subscribers:
                self.subscribers[agent_id] = []
            
            self.subscribers[agent_id].append(callback)
            
            # Start listener if not already running
            if self._listen_task is None or self._listen_task.done():
                self._listen_task = asyncio.create_task(self._listen_loop())
            
            logger.info(f"Subscribed to agent:{agent_id}:inbox")
            return True
            
        except Exception as e:
            logger.error(f"Failed to subscribe: {e}")
            return False
    
    async def _listen_loop(self):
        """Background task to listen for messages"""
        try:
            self._pubsub = self.redis.pubsub()
            
            # Subscribe to all registered agent channels
            channels = [f"agent:{agent_id}:inbox" for agent_id in self.subscribers.keys()]
            channels.append("agent:broadcast")
            
            await self._pubsub.subscribe(*channels)
            logger.info(f"Listening on {len(channels)} channels")
            
            async for message in self._pubsub.listen():
                if message['type'] == 'message':
                    await self._handle_message(message)
                    
        except Exception as e:
            logger.error(f"Listen loop error: {e}")
        finally:
            if self._pubsub:
                await self._pubsub.close()
    
    async def _handle_message(self, redis_message: Dict):
        """Handle incoming message from Redis"""
        try:
            msg_data = json.loads(redis_message['data'])
            message = Message.from_dict(msg_data)
            
            # Route to subscribers
            agent_id = message.to_agent
            if agent_id in self.subscribers:
                for callback in self.subscribers[agent_id]:
                    await callback(message)
            
            # Also notify broadcast subscribers
            if "broadcast" in self.subscribers:
                for callback in self.subscribers["broadcast"]:
                    await callback(message)
                    
        except Exception as e:
            logger.error(f"Failed to handle message: {e}")
    
    async def _log_message(self, message: Message):
        """Log message to event store (MongoDB)"""
        if not self.db:
            return
        
        try:
            event_doc = message.to_dict()
            event_doc['_collection'] = 'agent_bus_events'
            await self.db.agent_bus_events.insert_one(event_doc)
        except Exception as e:
            logger.error(f"Failed to log message: {e}")
    
    async def get_message_history(self, agent_id: Optional[str] = None, 
                                  limit: int = 100) -> List[Dict]:
        """
        Retrieve message history from event store
        
        Args:
            agent_id: Filter by agent ID (None for all)
            limit: Maximum number of messages
        
        Returns:
            List of messages
        """
        if not self.db:
            return []
        
        try:
            query = {}
            if agent_id:
                query['$or'] = [
                    {'from': agent_id},
                    {'to': agent_id}
                ]
            
            cursor = self.db.agent_bus_events.find(
                query,
                {'_id': 0}
            ).sort('timestamp', -1).limit(limit)
            
            return await cursor.to_list(length=limit)
        except Exception as e:
            logger.error(f"Failed to get history: {e}")
            return []
    
    async def close(self):
        """Close Redis connection"""
        if self._pubsub:
            await self._pubsub.close()
        if self.redis:
            await self.redis.close()
        if self._listen_task:
            self._listen_task.cancel()
        logger.info("AgentBus closed")
