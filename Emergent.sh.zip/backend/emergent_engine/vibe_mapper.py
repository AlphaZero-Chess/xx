from typing import Dict, List

class VibeMapper:
    """Maps vibe descriptors to design language"""
    
    def __init__(self):
        self.vibe_mappings = {
            'cosmic': {
                'colors': ['#1e1b4b', '#312e81', '#4c1d95', '#6366f1', '#8b5cf6'],
                'mood': 'mysterious, expansive',
                'fonts': ['Orbitron', 'Space Grotesk', 'Exo 2']
            },
            'calm': {
                'colors': ['#dbeafe', '#bfdbfe', '#93c5fd', '#60a5fa', '#3b82f6'],
                'mood': 'peaceful, serene',
                'fonts': ['Inter', 'Lato', 'Nunito']
            },
            'serene': {
                'colors': ['#d1fae5', '#a7f3d0', '#6ee7b7', '#34d399', '#10b981'],
                'mood': 'tranquil, balanced',
                'fonts': ['Merriweather', 'Spectral', 'Inter']
            },
            'vibrant': {
                'colors': ['#fef3c7', '#fde047', '#facc15', '#f59e0b', '#ef4444'],
                'mood': 'energetic, lively',
                'fonts': ['Poppins', 'Montserrat', 'Nunito']
            },
            'minimal': {
                'colors': ['#ffffff', '#f8fafc', '#e2e8f0', '#94a3b8', '#1e293b'],
                'mood': 'clean, focused',
                'fonts': ['Inter', 'IBM Plex Sans', 'Work Sans']
            },
            'playful': {
                'colors': ['#fce7f3', '#fbcfe8', '#f9a8d4', '#f472b6', '#ec4899'],
                'mood': 'fun, whimsical',
                'fonts': ['Fredoka', 'Nunito', 'Quicksand']
            },
            'professional': {
                'colors': ['#f0f9ff', '#dbeafe', '#3b82f6', '#1e40af', '#1e3a8a'],
                'mood': 'trustworthy, structured',
                'fonts': ['IBM Plex Sans', 'Inter', 'Roboto']
            },
            'dark': {
                'colors': ['#0f172a', '#1e293b', '#334155', '#475569', '#64748b'],
                'mood': 'sophisticated, focused',
                'fonts': ['Inter', 'JetBrains Mono', 'Space Grotesk']
            },
            'futuristic': {
                'colors': ['#0ea5e9', '#06b6d4', '#14b8a6', '#6366f1', '#8b5cf6'],
                'mood': 'innovative, tech-forward',
                'fonts': ['Orbitron', 'Rajdhani', 'Exo 2']
            }
        }
    
    def map(self, vibe_string: str) -> str:
        """Map vibe descriptors to design hints"""
        if not vibe_string:
            return self._default_hints()
        
        vibes = [v.strip().lower() for v in vibe_string.split(',')]
        hints = []
        
        for vibe in vibes:
            if vibe in self.vibe_mappings:
                mapping = self.vibe_mappings[vibe]
                hints.append(f"{vibe.capitalize()}: {mapping['mood']}. Use {', '.join(mapping['fonts'][:2])} fonts.")
        
        return ' '.join(hints) if hints else self._default_hints()
    
    def _default_hints(self) -> str:
        """Default design hints when no vibes specified"""
        return "Modern, clean design with good contrast and readability. Use Inter or similar sans-serif fonts."
    
    def get_color_palette(self, vibe: str) -> List[str]:
        """Get color palette for a specific vibe"""
        vibe_lower = vibe.lower().strip()
        if vibe_lower in self.vibe_mappings:
            return self.vibe_mappings[vibe_lower]['colors']
        return ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981']  # Default
