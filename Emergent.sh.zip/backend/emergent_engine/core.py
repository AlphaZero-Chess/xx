import json
import logging
from typing import Dict, Any, List, Optional
from .agents import (
    ArchitectAgent,
    CoderAgent,
    DesignerAgent,
    DevOpsAgent,
    CriticAgent
)
from .models import get_model_loader
from .intent_parser import IntentParser
from .vibe_mapper import VibeMapper
from .project_synthesizer import ProjectSynthesizer

logger = logging.getLogger(__name__)

class EmergentEngine:
    """Main orchestration engine for agentic app generation"""
    
    def __init__(self, model_name: Optional[str] = None):
        self.model_loader = get_model_loader()
        self.model_name = model_name
        
        # Initialize agents
        self.architect = ArchitectAgent(self.model_loader)
        self.coder = CoderAgent(self.model_loader)
        self.designer = DesignerAgent(self.model_loader)
        self.devops = DevOpsAgent(self.model_loader)
        self.critic = CriticAgent(self.model_loader)
        
        # Utilities
        self.intent_parser = IntentParser()
        self.vibe_mapper = VibeMapper()
        self.synthesizer = ProjectSynthesizer()
        
        # Agent toggles
        self.active_agents = {
            'architect': True,
            'coder': True,
            'designer': True,
            'devops': True,
            'critic': True
        }
        
        logger.info("EmergentEngine initialized")
    
    def load_model(self, model_name: str, quantize: bool = False) -> bool:
        """Load a specific Hugging Face model"""
        self.model_name = model_name
        return self.model_loader.load_model(model_name, quantize)
    
    def toggle_agent(self, agent_name: str, enabled: bool):
        """Enable or disable a specific agent"""
        if agent_name in self.active_agents:
            self.active_agents[agent_name] = enabled
            logger.info(f"Agent {agent_name} {'enabled' if enabled else 'disabled'}")
    
    async def generate_project(self, user_request: str, 
                              vibes: str = "",
                              temperature: float = 0.7) -> Dict[str, Any]:
        """Main generation pipeline"""
        try:
            logger.info(f"Starting project generation: {user_request[:50]}...")
            
            # Step 1: Parse intent
            intent = self.intent_parser.parse(user_request)
            logger.info(f"Intent parsed: {intent.get('type', 'general')}")
            
            # Step 2: Map vibes to design language
            vibe_keywords = vibes if vibes else intent.get('vibes', '')
            design_hints = self.vibe_mapper.map(vibe_keywords)
            
            # Step 3: Architect - System design
            architecture_json = ""
            if self.active_agents['architect']:
                logger.info("Running ArchitectAgent...")
                architecture_json = self.architect.process(user_request, temperature)
                logger.info("Architecture generated")
            
            # Step 4: Designer - UI/UX design system
            design_json = ""
            if self.active_agents['designer']:
                logger.info("Running DesignerAgent...")
                design_request = f"{user_request}\n\nDesign hints: {design_hints}"
                design_json = self.designer.process(design_request, vibe_keywords, temperature)
                logger.info("Design system generated")
            
            # Step 5: Coder - Generate code
            code_json = ""
            if self.active_agents['coder']:
                logger.info("Running CoderAgent...")
                code_json = self.coder.process(architecture_json, user_request, temperature)
                logger.info("Code generated")
            
            # Step 6: DevOps - Deployment configs
            devops_json = ""
            if self.active_agents['devops']:
                logger.info("Running DevOpsAgent...")
                devops_json = self.devops.process(architecture_json, user_request, temperature)
                logger.info("DevOps configs generated")
            
            # Step 7: Critic - Review and validate
            critique_json = ""
            if self.active_agents['critic']:
                logger.info("Running CriticAgent...")
                critique_json = self.critic.process(code_json, temperature)
                logger.info("Code review completed")
            
            # Step 8: Synthesize project
            logger.info("Synthesizing project...")
            project = self.synthesizer.synthesize(
                user_request=user_request,
                architecture=architecture_json,
                design=design_json,
                code=code_json,
                devops=devops_json,
                critique=critique_json
            )
            
            logger.info("Project generation completed")
            
            return {
                'success': True,
                'project': project,
                'metadata': {
                    'model': self.model_name or 'simulated',
                    'temperature': temperature,
                    'agents_used': [k for k, v in self.active_agents.items() if v]
                }
            }
            
        except Exception as e:
            logger.error(f"Project generation failed: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    async def chat(self, message: str, context: List[Dict] = None) -> str:
        """Conversational interface"""
        try:
            # Simple chat mode - just use model to respond
            response = self.model_loader.generate(
                prompt=message,
                system_prompt="You are Emergent.sh, an AI-powered platform that helps users build full-stack applications through conversation. Be helpful, concise, and guide users in describing what they want to build.",
                temperature=0.8
            )
            return response
        except Exception as e:
            logger.error(f"Chat failed: {str(e)}")
            return "I'm having trouble processing that. Could you rephrase?"
