import json
import logging
import os
from typing import Dict, Any, List, Optional
from .agents import (
    ArchitectAgent,
    CoderAgent,
    DesignerAgent,
    DevOpsAgent,
    CriticAgent
)
from .models import ModelRouter
from .memory import RedisMemoryAdapter, MemoryStore, EmbeddingEngine, ReflectiveMemory
from .intent_parser import IntentParser
from .vibe_mapper import VibeMapper
from .project_synthesizer import ProjectSynthesizer

# Phase 3 imports
from .agent_bus import AgentBus
from .task_graph import TaskGraphManager
from .cot_buffer import CoTBuffer

logger = logging.getLogger(__name__)

class EmergentEngine:
    """
    Main orchestration engine for agentic app generation
    Phase 3: Advanced intelligence with agent communication and task graphs
    """
    
    def __init__(self, model_name: Optional[str] = None, db=None):
        """
        Initialize EmergentEngine with Phase 3 capabilities
        
        Args:
            model_name: Optional initial model to load
            db: MongoDB database instance for persistence
        """
        # Phase 2: Model Router with multi-provider support
        provider_priority = os.environ.get(
            'MODEL_PRIORITY', 
            'ollama,lmstudio,huggingface,simulated'
        ).split(',')
        self.model_router = ModelRouter(priority=provider_priority)
        self.model_name = model_name
        self.db = db
        
        # Phase 2: Memory System (Redis + MongoDB)
        self.redis_adapter = RedisMemoryAdapter()
        self.memory_store = MemoryStore(self.redis_adapter, db)
        self.embedding_engine = EmbeddingEngine()
        self.reflective_memory = ReflectiveMemory(self.memory_store, self.embedding_engine)
        
        # Phase 3: Agent Communication Bus
        self.agent_bus = AgentBus(db=db)
        
        # Phase 3: Task Graph Manager
        self.task_graph_manager = TaskGraphManager(agent_bus=self.agent_bus, db=db)
        
        # Phase 3: Chain-of-Thought Buffer
        self.cot_buffer = CoTBuffer(redis_adapter=self.redis_adapter)
        
        # Initialize agents with new model router
        self.architect = ArchitectAgent(self.model_router)
        self.coder = CoderAgent(self.model_router)
        self.designer = DesignerAgent(self.model_router)
        self.devops = DevOpsAgent(self.model_router)
        self.critic = CriticAgent(self.model_router)
        
        # Utilities
        self.intent_parser = IntentParser()
        self.vibe_mapper = VibeMapper()
        self.synthesizer = ProjectSynthesizer()
        
        # Agent toggles
        self.active_agents = {
            'architect': True,
            'coder': True,
            'designer': True,
            'devops': True,
            'critic': True
        }
        
        # Phase 2: Session management
        self.current_session_id = None
        
        # Phase 3: Active vibe state
        self.active_vibe = None
        
        logger.info(f"EmergentEngine Phase 3 initialized")
        logger.info(f"Model provider priority: {provider_priority}")
        logger.info(f"Redis connected: {self.redis_adapter.is_connected()}")
        logger.info(f"Embedding engine: {self.embedding_engine.model_name}")
        logger.info(f"Agent Bus: initialized")
        logger.info(f"Task Graph Manager: initialized")
        logger.info(f"CoT Buffer: initialized")
    
    def load_model(self, model_name: str, provider: Optional[str] = None, 
                   quantize: bool = False) -> bool:
        """
        Load a model using the model router
        
        Args:
            model_name: Model name
            provider: Specific provider or None for auto-detection
            quantize: Enable quantization (HuggingFace only)
        
        Returns:
            Success status
        """
        self.model_name = model_name
        return self.model_router.load_model(model_name, provider, quantize=quantize)
    
    def toggle_agent(self, agent_name: str, enabled: bool):
        """Enable or disable a specific agent"""
        if agent_name in self.active_agents:
            self.active_agents[agent_name] = enabled
            logger.info(f"Agent {agent_name} {'enabled' if enabled else 'disabled'}")
    
    async def generate_project(self, user_request: str, 
                              vibes: str = "",
                              temperature: float = 0.7,
                              session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Main generation pipeline with Phase 2 reflective memory
        
        Args:
            user_request: User's project description
            vibes: Aesthetic keywords
            temperature: Generation temperature
            session_id: Optional session identifier for memory continuity
        
        Returns:
            Generation result with project data
        """
        try:
            # Set session context
            if session_id:
                self.current_session_id = session_id
            else:
                from datetime import datetime
                self.current_session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            logger.info(f"Starting project generation: {user_request[:50]}...")
            logger.info(f"Session: {self.current_session_id}")
            
            # Phase 2: Remember the request
            await self.reflective_memory.remember(
                agent_id="orchestrator",
                content=f"User request: {user_request}",
                metadata={"vibes": vibes, "temperature": temperature},
                importance=0.9,
                persist=True
            )
            
            # Step 1: Parse intent
            intent = self.intent_parser.parse(user_request)
            logger.info(f"Intent parsed: {intent.get('type', 'general')}")
            
            # Step 2: Map vibes to design language
            vibe_keywords = vibes if vibes else intent.get('vibes', '')
            design_hints = self.vibe_mapper.map(vibe_keywords)
            
            # Phase 2: Check for similar past projects
            similar_memories = await self.reflective_memory.recall(
                agent_id="orchestrator",
                query=user_request,
                top_k=3,
                min_similarity=0.4  # Lowered from 0.6 for better recall (Phase 3 fix)
            )
            
            context_hint = ""
            if similar_memories:
                logger.info(f"Found {len(similar_memories)} similar past projects")
                context_hint = "\n\nLearning from past experience:\n"
                for mem in similar_memories[:2]:
                    context_hint += f"- {mem['content'][:100]}...\n"
            
            # Step 3: Architect - System design
            architecture_json = ""
            if self.active_agents['architect']:
                logger.info("Running ArchitectAgent...")
                enhanced_request = user_request + context_hint
                architecture_json = self.architect.process(enhanced_request, temperature)
                
                # Remember architecture decisions
                await self.reflective_memory.remember(
                    agent_id="architect",
                    content=f"Architecture for '{user_request[:50]}': {architecture_json[:200]}",
                    importance=0.8,
                    persist=True
                )
                logger.info("Architecture generated")
            
            # Step 4: Designer - UI/UX design system
            design_json = ""
            if self.active_agents['designer']:
                logger.info("Running DesignerAgent...")
                design_request = f"{user_request}\n\nDesign hints: {design_hints}"
                design_json = self.designer.process(design_request, vibe_keywords, temperature)
                
                # Remember design decisions
                await self.reflective_memory.remember(
                    agent_id="designer",
                    content=f"Design system for '{user_request[:50]}' with vibes '{vibe_keywords}'",
                    metadata={"vibes": vibe_keywords},
                    importance=0.7,
                    persist=True
                )
                logger.info("Design system generated")
            
            # Step 5: Coder - Generate code
            code_json = ""
            if self.active_agents['coder']:
                logger.info("Running CoderAgent...")
                code_json = self.coder.process(architecture_json, user_request, temperature)
                
                # Remember code patterns
                await self.reflective_memory.remember(
                    agent_id="coder",
                    content=f"Code generated for '{user_request[:50]}'",
                    importance=0.6,
                    persist=False
                )
                logger.info("Code generated")
            
            # Step 6: DevOps - Deployment configs
            devops_json = ""
            if self.active_agents['devops']:
                logger.info("Running DevOpsAgent...")
                devops_json = self.devops.process(architecture_json, user_request, temperature)
                logger.info("DevOps configs generated")
            
            # Step 7: Critic - Review and validate
            critique_json = ""
            if self.active_agents['critic']:
                logger.info("Running CriticAgent...")
                critique_json = self.critic.process(code_json, temperature)
                
                # Remember critique insights
                await self.reflective_memory.remember(
                    agent_id="critic",
                    content=f"Critique insights: {critique_json[:200]}",
                    importance=0.75,
                    persist=True
                )
                logger.info("Code review completed")
            
            # Step 8: Synthesize project
            logger.info("Synthesizing project...")
            project = self.synthesizer.synthesize(
                user_request=user_request,
                architecture=architecture_json,
                design=design_json,
                code=code_json,
                devops=devops_json,
                critique=critique_json
            )
            
            # Phase 2: Store project success in memory
            await self.reflective_memory.remember(
                agent_id="orchestrator",
                content=f"Successfully generated: {project.get('name', 'project')}",
                metadata={"session_id": self.current_session_id},
                importance=0.85,
                persist=True
            )
            
            logger.info("Project generation completed")
            
            return {
                'success': True,
                'project': project,
                'metadata': {
                    'model': self.model_name or self.model_router.get_active_provider() or 'simulated',
                    'provider': self.model_router.get_active_provider(),
                    'temperature': temperature,
                    'agents_used': [k for k, v in self.active_agents.items() if v],
                    'session_id': self.current_session_id,
                    'memory_enabled': self.redis_adapter.is_connected()
                }
            }
            
        except Exception as e:
            logger.error(f"Project generation failed: {str(e)}")
            
            # Remember failure for learning
            try:
                await self.reflective_memory.remember(
                    agent_id="orchestrator",
                    content=f"Generation failed for '{user_request[:50]}': {str(e)}",
                    importance=0.8,
                    persist=True
                )
            except:
                pass
            
            return {
                'success': False,
                'error': str(e)
            }
    
    async def chat(self, message: str, context: List[Dict] = None) -> str:
        """
        Conversational interface with Phase 2 memory
        
        Args:
            message: User message
            context: Optional conversation context
        
        Returns:
            AI response
        """
        try:
            # Phase 2: Remember the conversation
            await self.reflective_memory.remember(
                agent_id="chat",
                content=f"User: {message}",
                importance=0.5,
                persist=False
            )
            
            # Recall relevant past conversations
            relevant_memories = await self.reflective_memory.recall(
                agent_id="chat",
                query=message,
                top_k=3
            )
            
            # Build context-aware system prompt
            system_prompt = """You are Emergent.sh, an AI-powered platform that helps users build full-stack applications through conversation. Be helpful, concise, and guide users in describing what they want to build."""
            
            if relevant_memories:
                system_prompt += "\n\nRecent conversation context:\n"
                for mem in relevant_memories:
                    system_prompt += f"- {mem['content']}\n"
            
            # Generate response
            response = self.model_router.generate(
                prompt=message,
                system_prompt=system_prompt,
                temperature=0.8
            )
            
            # Remember the response
            await self.reflective_memory.remember(
                agent_id="chat",
                content=f"Assistant: {response}",
                importance=0.5,
                persist=False
            )
            
            return response
        except Exception as e:
            logger.error(f"Chat failed: {str(e)}")
            return "I'm having trouble processing that. Could you rephrase?"
    
    async def get_agent_memories(self, agent_id: str, query: Optional[str] = None) -> List[Dict]:
        """
        Retrieve agent memories
        
        Args:
            agent_id: Agent identifier
            query: Optional semantic query
        
        Returns:
            List of memories
        """
        if query:
            return await self.reflective_memory.recall(agent_id, query, top_k=10)
        else:
            return await self.reflective_memory.get_important_memories(agent_id)
    
    async def reflect_on_topic(self, agent_id: str, topic: str) -> str:
        """
        Have an agent reflect on a topic based on its memories
        
        Args:
            agent_id: Agent identifier
            topic: Topic to reflect on
        
        Returns:
            Reflection text
        """
        return await self.reflective_memory.reflect(agent_id, topic)
    
    def get_system_info(self) -> Dict[str, Any]:
        """
        Get Phase 3 system information
        
        Returns:
            System status and capabilities
        """
        return {
            "phase": "3.0",
            "model_router": {
                "active_provider": self.model_router.get_active_provider(),
                "available_providers": self.model_router.get_available_providers(),
                "priority": self.model_router.priority
            },
            "memory": {
                "redis_connected": self.redis_adapter.is_connected(),
                "embedding_model": self.embedding_engine.model_name,
                "current_session": self.current_session_id
            },
            "agent_bus": self.agent_bus.get_connection_info(),
            "task_graph": {
                "active_graphs": len(self.task_graph_manager.graphs)
            },
            "cot_buffer": {
                "active_sessions": len(self.cot_buffer.session_buffers)
            },
            "agents": self.active_agents,
            "active_vibe": self.active_vibe
        }
    
    # ========== Phase 3 Methods ==========
    
    async def initialize_phase3(self):
        """Initialize Phase 3 components (connect agent bus, etc.)"""
        await self.agent_bus.connect()
        logger.info("Phase 3 components initialized")
    
    async def send_agent_message(self, from_agent: str, to_agent: str, 
                                 msg_type: str, payload: Dict[str, Any]) -> bool:
        """
        Send message between agents
        
        Args:
            from_agent: Source agent
            to_agent: Destination agent
            msg_type: Message type
            payload: Message payload
        
        Returns:
            Success status
        """
        from .agent_bus import Message
        message = Message(
            from_agent=from_agent,
            to_agent=to_agent,
            msg_type=msg_type,
            payload=payload
        )
        return await self.agent_bus.publish(message)
    
    async def get_agent_message_history(self, agent_id: Optional[str] = None, 
                                       limit: int = 100) -> List[Dict]:
        """Get message history for an agent"""
        return await self.agent_bus.get_message_history(agent_id, limit)
    
    async def create_task_graph(self, tasks: List[Dict[str, Any]]):
        """
        Create and return a task graph
        
        Args:
            tasks: List of task definitions
        
        Returns:
            TaskGraph instance or None
        """
        return await self.task_graph_manager.create_graph(tasks)
    
    async def execute_task_graph(self, graph_id: str) -> bool:
        """Execute a task graph"""
        return await self.task_graph_manager.execute_graph(graph_id)
    
    async def get_task_graph_status(self, graph_id: str) -> Optional[Dict]:
        """Get task graph status"""
        graph = await self.task_graph_manager.get_graph(graph_id)
        if graph:
            return graph.to_dict()
        return None
    
    async def add_cot_step(self, agent_id: str, thought: str, reason: str, 
                          confidence: float = 0.5, sources: Optional[List[str]] = None):
        """
        Add a chain-of-thought step for an agent
        
        Args:
            agent_id: Agent identifier
            thought: The thought content
            reason: Justification
            confidence: Confidence score
            sources: Optional sources
        """
        if not self.current_session_id:
            logger.warning("No active session for CoT")
            return False
        
        return await self.cot_buffer.add_step(
            session_id=self.current_session_id,
            agent_id=agent_id,
            thought=thought,
            reason=reason,
            confidence=confidence,
            sources=sources
        )
    
    async def get_cot_steps(self, agent_id: str, session_id: Optional[str] = None) -> List:
        """Get chain-of-thought steps for an agent"""
        sid = session_id or self.current_session_id
        if not sid:
            return []
        steps = await self.cot_buffer.get_steps(sid, agent_id)
        return [s.to_dict() for s in steps]
    
    async def get_cot_summary(self, agent_id: str, session_id: Optional[str] = None) -> str:
        """Get CoT summary for an agent"""
        sid = session_id or self.current_session_id
        if not sid:
            return "No active session"
        return await self.cot_buffer.get_summary(sid, agent_id)
    
    def load_vibe_ontology(self) -> Dict[str, Any]:
        """Load vibe ontology from JSON"""
        try:
            import json
            from pathlib import Path
            ontology_path = Path(__file__).parent / "vibe_ontology.json"
            with open(ontology_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load vibe ontology: {e}")
            return {}
    
    def set_active_vibe(self, vibe_name: str) -> bool:
        """Set the active vibe for the system"""
        ontology = self.load_vibe_ontology()
        if vibe_name in ontology:
            self.active_vibe = {
                "name": vibe_name,
                **ontology[vibe_name]
            }
            logger.info(f"Active vibe set to: {vibe_name}")
            return True
        return False
    
    def get_vibe_state(self) -> Dict[str, Any]:
        """Get current vibe state"""
        return self.active_vibe or {"name": "default", "description": "No vibe set"}
