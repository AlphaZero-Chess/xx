import json
import logging
import os
from typing import Dict, Any, List, Optional
from .agents import (
    ArchitectAgent,
    CoderAgent,
    DesignerAgent,
    DevOpsAgent,
    CriticAgent
)
from .models import ModelRouter
from .memory import RedisMemoryAdapter, MemoryStore, EmbeddingEngine, ReflectiveMemory
from .intent_parser import IntentParser
from .vibe_mapper import VibeMapper
from .project_synthesizer import ProjectSynthesizer

logger = logging.getLogger(__name__)

class EmergentEngine:
    """
    Main orchestration engine for agentic app generation
    Phase 2: Enhanced with model routing and reflective memory
    """
    
    def __init__(self, model_name: Optional[str] = None, db=None):
        """
        Initialize EmergentEngine with Phase 2 capabilities
        
        Args:
            model_name: Optional initial model to load
            db: MongoDB database instance for persistence
        """
        # Phase 2: Model Router with multi-provider support
        provider_priority = os.environ.get(
            'MODEL_PRIORITY', 
            'ollama,lmstudio,huggingface,simulated'
        ).split(',')
        self.model_router = ModelRouter(priority=provider_priority)
        self.model_name = model_name
        
        # Phase 2: Memory System (Redis + MongoDB)
        self.redis_adapter = RedisMemoryAdapter()
        self.memory_store = MemoryStore(self.redis_adapter, db)
        self.embedding_engine = EmbeddingEngine()
        self.reflective_memory = ReflectiveMemory(self.memory_store, self.embedding_engine)
        
        # Initialize agents with new model router
        self.architect = ArchitectAgent(self.model_router)
        self.coder = CoderAgent(self.model_router)
        self.designer = DesignerAgent(self.model_router)
        self.devops = DevOpsAgent(self.model_router)
        self.critic = CriticAgent(self.model_router)
        
        # Utilities
        self.intent_parser = IntentParser()
        self.vibe_mapper = VibeMapper()
        self.synthesizer = ProjectSynthesizer()
        
        # Agent toggles
        self.active_agents = {
            'architect': True,
            'coder': True,
            'designer': True,
            'devops': True,
            'critic': True
        }
        
        # Phase 2: Session management
        self.current_session_id = None
        
        logger.info(f"EmergentEngine Phase 2 initialized")
        logger.info(f"Model provider priority: {provider_priority}")
        logger.info(f"Redis connected: {self.redis_adapter.is_connected()}")
        logger.info(f"Embedding engine: {self.embedding_engine.model_name}")
    
    def load_model(self, model_name: str, provider: Optional[str] = None, 
                   quantize: bool = False) -> bool:
        """
        Load a model using the model router
        
        Args:
            model_name: Model name
            provider: Specific provider or None for auto-detection
            quantize: Enable quantization (HuggingFace only)
        
        Returns:
            Success status
        """
        self.model_name = model_name
        return self.model_router.load_model(model_name, provider, quantize=quantize)
    
    def toggle_agent(self, agent_name: str, enabled: bool):
        """Enable or disable a specific agent"""
        if agent_name in self.active_agents:
            self.active_agents[agent_name] = enabled
            logger.info(f"Agent {agent_name} {'enabled' if enabled else 'disabled'}")
    
    async def generate_project(self, user_request: str, 
                              vibes: str = "",
                              temperature: float = 0.7,
                              session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Main generation pipeline with Phase 2 reflective memory
        
        Args:
            user_request: User's project description
            vibes: Aesthetic keywords
            temperature: Generation temperature
            session_id: Optional session identifier for memory continuity
        
        Returns:
            Generation result with project data
        """
        try:
            # Set session context
            if session_id:
                self.current_session_id = session_id
            else:
                from datetime import datetime
                self.current_session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            logger.info(f"Starting project generation: {user_request[:50]}...")
            logger.info(f"Session: {self.current_session_id}")
            
            # Phase 2: Remember the request
            await self.reflective_memory.remember(
                agent_id="orchestrator",
                content=f"User request: {user_request}",
                metadata={"vibes": vibes, "temperature": temperature},
                importance=0.9,
                persist=True
            )
            
            # Step 1: Parse intent
            intent = self.intent_parser.parse(user_request)
            logger.info(f"Intent parsed: {intent.get('type', 'general')}")
            
            # Step 2: Map vibes to design language
            vibe_keywords = vibes if vibes else intent.get('vibes', '')
            design_hints = self.vibe_mapper.map(vibe_keywords)
            
            # Phase 2: Check for similar past projects
            similar_memories = await self.reflective_memory.recall(
                agent_id="orchestrator",
                query=user_request,
                top_k=3,
                min_similarity=0.6
            )
            
            context_hint = ""
            if similar_memories:
                logger.info(f"Found {len(similar_memories)} similar past projects")
                context_hint = "\n\nLearning from past experience:\n"
                for mem in similar_memories[:2]:
                    context_hint += f"- {mem['content'][:100]}...\n"
            
            # Step 3: Architect - System design
            architecture_json = ""
            if self.active_agents['architect']:
                logger.info("Running ArchitectAgent...")
                enhanced_request = user_request + context_hint
                architecture_json = self.architect.process(enhanced_request, temperature)
                
                # Remember architecture decisions
                await self.reflective_memory.remember(
                    agent_id="architect",
                    content=f"Architecture for '{user_request[:50]}': {architecture_json[:200]}",
                    importance=0.8,
                    persist=True
                )
                logger.info("Architecture generated")
            
            # Step 4: Designer - UI/UX design system
            design_json = ""
            if self.active_agents['designer']:
                logger.info("Running DesignerAgent...")
                design_request = f"{user_request}\n\nDesign hints: {design_hints}"
                design_json = self.designer.process(design_request, vibe_keywords, temperature)
                
                # Remember design decisions
                await self.reflective_memory.remember(
                    agent_id="designer",
                    content=f"Design system for '{user_request[:50]}' with vibes '{vibe_keywords}'",
                    metadata={"vibes": vibe_keywords},
                    importance=0.7,
                    persist=True
                )
                logger.info("Design system generated")
            
            # Step 5: Coder - Generate code
            code_json = ""
            if self.active_agents['coder']:
                logger.info("Running CoderAgent...")
                code_json = self.coder.process(architecture_json, user_request, temperature)
                
                # Remember code patterns
                await self.reflective_memory.remember(
                    agent_id="coder",
                    content=f"Code generated for '{user_request[:50]}'",
                    importance=0.6,
                    persist=False
                )
                logger.info("Code generated")
            
            # Step 6: DevOps - Deployment configs
            devops_json = ""
            if self.active_agents['devops']:
                logger.info("Running DevOpsAgent...")
                devops_json = self.devops.process(architecture_json, user_request, temperature)
                logger.info("DevOps configs generated")
            
            # Step 7: Critic - Review and validate
            critique_json = ""
            if self.active_agents['critic']:
                logger.info("Running CriticAgent...")
                critique_json = self.critic.process(code_json, temperature)
                
                # Remember critique insights
                await self.reflective_memory.remember(
                    agent_id="critic",
                    content=f"Critique insights: {critique_json[:200]}",
                    importance=0.75,
                    persist=True
                )
                logger.info("Code review completed")
            
            # Step 8: Synthesize project
            logger.info("Synthesizing project...")
            project = self.synthesizer.synthesize(
                user_request=user_request,
                architecture=architecture_json,
                design=design_json,
                code=code_json,
                devops=devops_json,
                critique=critique_json
            )
            
            # Phase 2: Store project success in memory
            await self.reflective_memory.remember(
                agent_id="orchestrator",
                content=f"Successfully generated: {project.get('name', 'project')}",
                metadata={"session_id": self.current_session_id},
                importance=0.85,
                persist=True
            )
            
            logger.info("Project generation completed")
            
            return {
                'success': True,
                'project': project,
                'metadata': {
                    'model': self.model_name or self.model_router.get_active_provider() or 'simulated',
                    'provider': self.model_router.get_active_provider(),
                    'temperature': temperature,
                    'agents_used': [k for k, v in self.active_agents.items() if v],
                    'session_id': self.current_session_id,
                    'memory_enabled': self.redis_adapter.is_connected()
                }
            }
            
        except Exception as e:
            logger.error(f"Project generation failed: {str(e)}")
            
            # Remember failure for learning
            try:
                await self.reflective_memory.remember(
                    agent_id="orchestrator",
                    content=f"Generation failed for '{user_request[:50]}': {str(e)}",
                    importance=0.8,
                    persist=True
                )
            except:
                pass
            
            return {
                'success': False,
                'error': str(e)
            }
    
    async def chat(self, message: str, context: List[Dict] = None) -> str:
        """
        Conversational interface with Phase 2 memory
        
        Args:
            message: User message
            context: Optional conversation context
        
        Returns:
            AI response
        """
        try:
            # Phase 2: Remember the conversation
            await self.reflective_memory.remember(
                agent_id="chat",
                content=f"User: {message}",
                importance=0.5,
                persist=False
            )
            
            # Recall relevant past conversations
            relevant_memories = await self.reflective_memory.recall(
                agent_id="chat",
                query=message,
                top_k=3
            )
            
            # Build context-aware system prompt
            system_prompt = """You are Emergent.sh, an AI-powered platform that helps users build full-stack applications through conversation. Be helpful, concise, and guide users in describing what they want to build."""
            
            if relevant_memories:
                system_prompt += "\n\nRecent conversation context:\n"
                for mem in relevant_memories:
                    system_prompt += f"- {mem['content']}\n"
            
            # Generate response
            response = self.model_router.generate(
                prompt=message,
                system_prompt=system_prompt,
                temperature=0.8
            )
            
            # Remember the response
            await self.reflective_memory.remember(
                agent_id="chat",
                content=f"Assistant: {response}",
                importance=0.5,
                persist=False
            )
            
            return response
        except Exception as e:
            logger.error(f"Chat failed: {str(e)}")
            return "I'm having trouble processing that. Could you rephrase?"
    
    async def get_agent_memories(self, agent_id: str, query: Optional[str] = None) -> List[Dict]:
        """
        Retrieve agent memories
        
        Args:
            agent_id: Agent identifier
            query: Optional semantic query
        
        Returns:
            List of memories
        """
        if query:
            return await self.reflective_memory.recall(agent_id, query, top_k=10)
        else:
            return await self.reflective_memory.get_important_memories(agent_id)
    
    async def reflect_on_topic(self, agent_id: str, topic: str) -> str:
        """
        Have an agent reflect on a topic based on its memories
        
        Args:
            agent_id: Agent identifier
            topic: Topic to reflect on
        
        Returns:
            Reflection text
        """
        return await self.reflective_memory.reflect(agent_id, topic)
    
    def get_system_info(self) -> Dict[str, Any]:
        """
        Get Phase 2 system information
        
        Returns:
            System status and capabilities
        """
        return {
            "phase": "2.1",
            "model_router": {
                "active_provider": self.model_router.get_active_provider(),
                "available_providers": self.model_router.get_available_providers(),
                "priority": self.model_router.priority
            },
            "memory": {
                "redis_connected": self.redis_adapter.is_connected(),
                "embedding_model": self.embedding_engine.model_name,
                "current_session": self.current_session_id
            },
            "agents": self.active_agents
        }
