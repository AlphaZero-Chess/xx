"""
Chain-of-Thought Buffer - Phase 3.3
Reflective reasoning logs for agents
"""

import json
import logging
import os
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


class CoTStep:
    """Single step in chain-of-thought reasoning"""
    
    def __init__(self,
                 step: int,
                 thought: str,
                 reason: str,
                 confidence: float = 0.5,
                 sources: Optional[List[str]] = None):
        self.step = step
        self.thought = thought
        self.reason = reason
        self.confidence = confidence
        self.sources = sources or []
        self.timestamp = datetime.now(timezone.utc).isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "thought": self.thought,
            "reason": self.reason,
            "confidence": self.confidence,
            "sources": self.sources,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CoTStep':
        step = cls(
            step=data['step'],
            thought=data['thought'],
            reason=data['reason'],
            confidence=data.get('confidence', 0.5),
            sources=data.get('sources', [])
        )
        step.timestamp = data['timestamp']
        return step


class CoTBuffer:
    """
    Chain-of-Thought buffer for agent reasoning
    Stores reasoning steps in Redis (ephemeral) and logs to disk
    """
    
    def __init__(self, redis_adapter=None, log_dir: str = "/app/logs/agent_thoughts"):
        self.redis = redis_adapter
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.session_buffers: Dict[str, List[CoTStep]] = {}
    
    async def add_step(self,
                      session_id: str,
                      agent_id: str,
                      thought: str,
                      reason: str,
                      confidence: float = 0.5,
                      sources: Optional[List[str]] = None) -> bool:
        """
        Add a reasoning step to the buffer
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            thought: The thought/reasoning content
            reason: Justification for the thought
            confidence: Confidence score (0-1)
            sources: Optional source references
        
        Returns:
            Success status
        """
        try:
            key = f"{session_id}:{agent_id}"
            
            # Get current steps
            if key not in self.session_buffers:
                self.session_buffers[key] = []
            
            step_num = len(self.session_buffers[key]) + 1
            step = CoTStep(
                step=step_num,
                thought=thought,
                reason=reason,
                confidence=confidence,
                sources=sources
            )
            
            self.session_buffers[key].append(step)
            
            # Store in Redis with TTL
            if self.redis and self.redis.is_connected():
                redis_key = f"cot:{key}"
                steps_json = json.dumps([s.to_dict() for s in self.session_buffers[key]])
                self.redis.remember(redis_key, steps_json, ttl=3600)
            
            # Log to file
            await self._log_to_file(session_id, agent_id, step)
            
            logger.debug(f"Added CoT step {step_num} for {agent_id} in session {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add CoT step: {e}")
            return False
    
    async def get_steps(self, session_id: str, agent_id: str) -> List[CoTStep]:
        """
        Retrieve reasoning steps for a session
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
        
        Returns:
            List of CoT steps
        """
        key = f"{session_id}:{agent_id}"
        
        # Check in-memory first
        if key in self.session_buffers:
            return self.session_buffers[key]
        
        # Try Redis
        if self.redis and self.redis.is_connected():
            redis_key = f"cot:{key}"
            steps_data = self.redis.recall(redis_key)
            if steps_data:
                try:
                    steps_list = json.loads(steps_data) if isinstance(steps_data, str) else steps_data
                    steps = [CoTStep.from_dict(s) for s in steps_list]
                    self.session_buffers[key] = steps
                    return steps
                except Exception as e:
                    logger.error(f"Failed to parse CoT steps from Redis: {e}")
        
        # Try loading from log file
        return await self._load_from_file(session_id, agent_id)
    
    async def _log_to_file(self, session_id: str, agent_id: str, step: CoTStep):
        """Write step to log file"""
        try:
            log_file = self.log_dir / f"{session_id}.log"
            
            with open(log_file, 'a') as f:
                log_entry = {
                    "agent_id": agent_id,
                    "step": step.to_dict()
                }
                f.write(json.dumps(log_entry) + "\n")
                
        except Exception as e:
            logger.error(f"Failed to log CoT step to file: {e}")
    
    async def _load_from_file(self, session_id: str, agent_id: str) -> List[CoTStep]:
        """Load steps from log file"""
        try:
            log_file = self.log_dir / f"{session_id}.log"
            
            if not log_file.exists():
                return []
            
            steps = []
            with open(log_file, 'r') as f:
                for line in f:
                    entry = json.loads(line)
                    if entry['agent_id'] == agent_id:
                        steps.append(CoTStep.from_dict(entry['step']))
            
            return steps
            
        except Exception as e:
            logger.error(f"Failed to load CoT steps from file: {e}")
            return []
    
    async def clear_session(self, session_id: str):
        """Clear all steps for a session"""
        keys_to_remove = [k for k in self.session_buffers.keys() if k.startswith(session_id)]
        for key in keys_to_remove:
            del self.session_buffers[key]
        
        logger.info(f"Cleared CoT buffer for session {session_id}")
    
    async def get_summary(self, session_id: str, agent_id: str) -> str:
        """
        Get a summary of reasoning steps
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
        
        Returns:
            Summary text
        """
        steps = await self.get_steps(session_id, agent_id)
        
        if not steps:
            return f"No reasoning steps found for {agent_id} in session {session_id}"
        
        summary_lines = [f"Chain-of-Thought Summary for {agent_id}:"]
        for step in steps:
            summary_lines.append(
                f"\nStep {step.step} (confidence: {step.confidence:.2f}):"
            )
            summary_lines.append(f"  Thought: {step.thought}")
            summary_lines.append(f"  Reason: {step.reason}")
            if step.sources:
                summary_lines.append(f"  Sources: {', '.join(step.sources)}")
        
        return "\n".join(summary_lines)
