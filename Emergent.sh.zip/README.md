# 🌌 Emergent.sh — Offline Agentic Vibe-Coding Platform

**"Build anything. Locally. With vibes."**

An offline-first, open-source LLM platform for agentic full-stack app generation using natural language. Transform conversational prompts into production-grade web apps through multi-agent orchestration.

---

## ✨ Features

### 🤖 Multi-Agent System
- **ArchitectAgent** — System architecture design
- **CoderAgent** — Full-stack code generation
- **DesignerAgent** — UI/UX design with vibe mapping
- **DevOpsAgent** — Deployment configurations
- **CriticAgent** — Code review and validation

### 🎨 Vibe-Coding Protocol
Transform aesthetic intentions into design language:
- `cosmic` → deep purples, blues, stellar themes
- `serene` → soft pastels, calming tones
- `futuristic` → tech-forward, innovative designs
- `minimal` → clean, focused interfaces

### 🔧 Core Capabilities
- **Offline-First**: Runs locally with Hugging Face models
- **Natural Language Input**: Describe apps conversationally
- **Multi-Tab Interface**: Generate, Preview, Projects, Settings
- **Real-Time Logs**: Watch agent orchestration in action
- **Project Export**: Download complete project configurations
- **Agent Controls**: Toggle individual agents on/off

---

## 🚀 Quick Start

### Access Platform
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8001/api

### How to Use

1. **Navigate to Generate Tab**
   - Enter your app description in natural language
   - Add vibe keywords (optional): cosmic, serene, minimal, etc.
   - Adjust temperature slider (0.1-1.0)

2. **Click Generate Project**
   - Watch real-time logs as agents work
   - See ArchitectAgent, CoderAgent, DesignerAgent in action

3. **Preview Results**
   - View architecture, design system, code files
   - Review deployment configs and critique
   - Download complete project as JSON

4. **Manage Settings**
   - Toggle individual agents on/off
   - Configure model settings
   - Customize generation pipeline

---

## 🧬 Architecture

```
/app/
├── backend/
│   ├── emergent_engine/       # Core agentic system
│   │   ├── agents/            # Specialized agents
│   │   ├── core.py            # Orchestration pipeline
│   │   ├── models.py          # HuggingFace integration
│   │   └── vibe_mapper.py     # Aesthetic mapping
│   └── server.py              # FastAPI application
├── frontend/
│   └── src/
│       ├── App.js             # React application
│       └── App.css            # Cosmic design system
```

---

## 🎯 Example Prompts

**Journaling App**
```
Create a mood-based journaling app with daily AI reflections and a calm, oceanic vibe
Vibes: serene, minimal, peaceful
```

**Task Manager**
```
Build a cosmic-themed task management app with AI-powered task suggestions
Vibes: cosmic, futuristic, tech
```

**Dashboard**
```
Design a professional analytics dashboard with real-time data visualization
Vibes: professional, clean, modern
```

---

## 🧠 Model Configuration

### Current Mode: Simulated
The platform currently runs in **simulated mode** with structured agent responses. This provides:
- Fast iteration and testing
- Understanding of agent capabilities
- No GPU requirements
- Instant results

### Optional: Real Hugging Face Models
To use actual LLMs, load models via API:

```bash
curl -X POST http://localhost:8001/api/emergent/model/load \
  -H "Content-Type: application/json" \
  -d '{"model_name": "mistralai/Mistral-7B-Instruct-v0.2", "quantize": true}'
```

**Recommended Models:**
- `mistralai/Mistral-7B-Instruct-v0.2` (14GB)
- `meta-llama/Llama-3.2-3B-Instruct` (6GB, lightweight)

---

## 🎨 Design System

### Color Palette
- **Primary**: Cyan `#06b6d4`
- **Secondary**: Purple `#8b5cf6`
- **Accent**: Pink `#ec4899`
- **Background**: Deep Space `#0a0e1a`

### Typography
- **Headings**: Space Grotesk
- **Code**: JetBrains Mono

### Design Philosophy
- Cosmic, futuristic aesthetic
- Glassmorphism with backdrop blur
- Smooth micro-animations
- Responsive, mobile-first design

---

## 🔌 API Endpoints

### Generate Project
```http
POST /api/emergent/generate
{
  "prompt": "Create a task manager",
  "vibes": "minimal",
  "temperature": 0.7
}
```

### List Projects
```http
GET /api/emergent/projects
```

### Toggle Agent
```http
POST /api/emergent/agent/toggle
{
  "agent_name": "coder",
  "enabled": false
}
```

### List Models
```http
GET /api/emergent/models
```

---

## 🛠️ Technology Stack

- **Backend**: FastAPI, Python 3.11, MongoDB
- **Frontend**: React 19, Tailwind CSS, Shadcn UI
- **AI/ML**: Hugging Face Transformers, PyTorch
- **Infrastructure**: Supervisor, Docker-ready

---

## 🚧 Roadmap

### Phase 1 ✅ (Complete - MVP)
- [x] Multi-agent orchestration
- [x] Simulated agent responses
- [x] React developer console
- [x] Vibe mapping protocol
- [x] Real-time logs
- [x] Project export

### Phase 2 (Next)
- [ ] Full HuggingFace model integration
- [ ] Ollama/LM Studio support
- [ ] Code execution sandbox
- [ ] Project templates
- [ ] WebSocket streaming

---

## 📊 System Requirements

### Minimum (Simulated Mode)
- CPU: 2 cores
- RAM: 4GB
- Storage: 5GB

### Recommended (Real Models)
- CPU: 8+ cores
- RAM: 16GB
- GPU: NVIDIA 16GB+ VRAM
- Storage: 50GB

---

## 🐛 Troubleshooting

**Backend Issues**
```bash
tail -f /var/log/supervisor/backend.err.log
sudo supervisorctl restart backend
```

**Frontend Issues**
```bash
sudo supervisorctl restart frontend
```

**MongoDB Connection**
```bash
mongo --eval "db.adminCommand('ping')"
```

---

## 📝 License

MIT License

---

## 🙏 Acknowledgments

- Inspired by Emergent.sh platform concept
- Built with FastAPI, React, MongoDB
- UI: Shadcn/UI components
- Models: Hugging Face Transformers

---

**Made with 🌟 and cosmic vibes**

*"Where emotion becomes architecture, and ideas become code"*
