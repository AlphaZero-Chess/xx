import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Brain, Clock, Star, Search, Zap } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import useWebSocket from '../hooks/useWebSocket';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;
const WS_URL = BACKEND_URL.replace('http', 'ws');

const MemoryInspector = ({ sessionId }) => {
  const [memories, setMemories] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAgent, setSelectedAgent] = useState('all');
  const [loading, setLoading] = useState(false);

  const agents = ['all', 'architect', 'coder', 'designer', 'devops', 'critic'];

  // WebSocket connection for live memory updates
  const { isConnected, lastMessage } = useWebSocket(
    `${WS_URL}/ws/memory`,
    {
      onMessage: (data) => {
        if (data.type === 'memory:update') {
          // Add new memory to the list
          setMemories(prev => [data.data.memory, ...prev]);
        }
      }
    }
  );

  const loadMemories = async (agent = 'all', query = '') => {
    setLoading(true);
    try {
      if (agent === 'all') {
        // Load memories for all agents
        const agents = ['architect', 'coder', 'designer', 'devops', 'critic'];
        const promises = agents.map(async (agentId) => {
          try {
            const response = await axios.post(`${API}/emergent/memory/recall`, {
              agent_id: agentId,
              query: query || null
            });
            return response.data.memories || [];
          } catch (err) {
            return [];
          }
        });
        
        const results = await Promise.all(promises);
        const allMemories = results.flat();
        setMemories(allMemories);
      } else {
        const response = await axios.post(`${API}/emergent/memory/recall`, {
          agent_id: agent,
          query: query || null
        });
        setMemories(response.data.memories || []);
      }
    } catch (error) {
      console.error('Failed to load memories:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMemories(selectedAgent, searchQuery);
  }, [selectedAgent]);

  const handleSearch = () => {
    loadMemories(selectedAgent, searchQuery);
  };

  const getImportanceColor = (importance) => {
    if (importance >= 0.8) return 'text-rose-400';
    if (importance >= 0.6) return 'text-amber-400';
    return 'text-slate-400';
  };

  return (
    <div className="memory-inspector" data-testid="memory-inspector">
      <Card className="p-6 bg-surface border-border">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-cyan-400" />
            <div>
              <h2 className="text-xl font-bold">Memory Inspector</h2>
              <p className="text-sm text-slate-400">
                {isConnected ? (
                  <span className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                    Live updates active
                  </span>
                ) : (
                  'Offline'
                )}
              </p>
            </div>
          </div>
          <Badge variant="outline" className="text-cyan-400 border-cyan-400">
            {memories.length} memories
          </Badge>
        </div>

        {/* Agent Filter */}
        <div className="flex gap-2 mb-4 flex-wrap">
          {agents.map((agent) => (
            <Button
              key={agent}
              variant={selectedAgent === agent ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedAgent(agent)}
              className={selectedAgent === agent ? 'bg-cyan-600' : ''}
              data-testid={`filter-${agent}`}
            >
              {agent.charAt(0).toUpperCase() + agent.slice(1)}
            </Button>
          ))}
        </div>

        {/* Search */}
        <div className="flex gap-2 mb-6">
          <Input
            placeholder="Search memories semantically..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="bg-background border-border"
            data-testid="memory-search"
          />
          <Button onClick={handleSearch} data-testid="search-button">
            <Search className="w-4 h-4" />
          </Button>
        </div>

        {/* Memory List */}
        <ScrollArea className="h-[500px]">
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <Zap className="w-8 h-8 text-cyan-400 animate-pulse" />
            </div>
          ) : memories.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-slate-400">
              <Brain className="w-12 h-12 mb-2 opacity-50" />
              <p>No memories found</p>
            </div>
          ) : (
            <div className="space-y-3">
              {memories.map((memory, idx) => (
                <div
                  key={idx}
                  className="memory-card p-4 bg-background border border-border rounded-lg hover:border-cyan-500/50 transition-colors"
                  data-testid={`memory-${idx}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {memory.metadata?.agent_id || 'unknown'}
                      </Badge>
                      {memory.similarity && (
                        <span className="text-xs text-slate-400">
                          {(memory.similarity * 100).toFixed(0)}% match
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Star
                        className={`w-4 h-4 ${getImportanceColor(memory.importance || 0.5)}`}
                        fill="currentColor"
                      />
                      <span className="text-xs text-slate-400">
                        {((memory.importance || 0.5) * 100).toFixed(0)}
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-200 mb-2">
                    {memory.content}
                  </p>
                  
                  {memory.timestamp && (
                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <Clock className="w-3 h-3" />
                      {new Date(memory.timestamp).toLocaleString()}
                    </div>
                  )}
                  
                  {memory.metadata && Object.keys(memory.metadata).length > 0 && (
                    <div className="mt-2 text-xs text-slate-400">
                      {Object.entries(memory.metadata).map(([key, value]) => (
                        <span key={key} className="mr-3">
                          {key}: {JSON.stringify(value)}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </Card>
    </div>
  );
};

export default MemoryInspector;
