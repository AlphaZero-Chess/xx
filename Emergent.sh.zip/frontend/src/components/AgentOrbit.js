import React, { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { MessageSquare, ArrowRight, Activity } from 'lucide-react';
import useWebSocket from '../hooks/useWebSocket';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const WS_URL = BACKEND_URL.replace('http', 'ws');

const AgentOrbit = () => {
  const [messages, setMessages] = useState([]);
  const [activeAgents, setActiveAgents] = useState(new Set());
  const canvasRef = useRef(null);

  const agents = ['architect', 'coder', 'designer', 'devops', 'critic'];
  const agentColors = {
    architect: '#06b6d4',
    coder: '#8b5cf6',
    designer: '#ec4899',
    devops: '#10b981',
    critic: '#f59e0b'
  };

  // WebSocket connection for agent messages
  const { isConnected, lastMessage } = useWebSocket(
    `${WS_URL}/ws/agents`,
    {
      onMessage: (data) => {
        if (data.type === 'agent:message') {
          const message = data.data;
          setMessages(prev => [...prev.slice(-20), message]); // Keep last 20
          setActiveAgents(prev => new Set([...prev, message.from, message.to]));
          
          // Remove from active after 3 seconds
          setTimeout(() => {
            setActiveAgents(prev => {
              const next = new Set(prev);
              next.delete(message.from);
              next.delete(message.to);
              return next;
            });
          }, 3000);
        }
      }
    }
  );

  // Simple visualization
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw center point
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = 150;

    // Draw agent nodes in a circle
    agents.forEach((agent, idx) => {
      const angle = (idx / agents.length) * 2 * Math.PI - Math.PI / 2;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);

      // Draw node
      ctx.beginPath();
      ctx.arc(x, y, activeAgents.has(agent) ? 15 : 10, 0, 2 * Math.PI);
      ctx.fillStyle = activeAgents.has(agent) 
        ? agentColors[agent] 
        : agentColors[agent] + '40';
      ctx.fill();
      ctx.strokeStyle = agentColors[agent];
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw label
      ctx.fillStyle = '#f1f5f9';
      ctx.font = '12px Space Grotesk';
      ctx.textAlign = 'center';
      ctx.fillText(agent, x, y + 30);
    });

    // Draw connections for recent messages
    const recentMessages = messages.slice(-5);
    recentMessages.forEach((msg, idx) => {
      const fromIdx = agents.indexOf(msg.from);
      const toIdx = agents.indexOf(msg.to);
      
      if (fromIdx === -1 || toIdx === -1) return;

      const fromAngle = (fromIdx / agents.length) * 2 * Math.PI - Math.PI / 2;
      const toAngle = (toIdx / agents.length) * 2 * Math.PI - Math.PI / 2;
      
      const fromX = centerX + radius * Math.cos(fromAngle);
      const fromY = centerY + radius * Math.sin(fromAngle);
      const toX = centerX + radius * Math.cos(toAngle);
      const toY = centerY + radius * Math.sin(toAngle);

      // Draw line with gradient
      const gradient = ctx.createLinearGradient(fromX, fromY, toX, toY);
      gradient.addColorStop(0, agentColors[msg.from] + '80');
      gradient.addColorStop(1, agentColors[msg.to] + '80');

      ctx.beginPath();
      ctx.moveTo(fromX, fromY);
      ctx.lineTo(toX, toY);
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 2 - idx * 0.3;
      ctx.stroke();

      // Draw arrow
      const arrowSize = 8;
      const angle = Math.atan2(toY - fromY, toX - fromX);
      ctx.beginPath();
      ctx.moveTo(toX, toY);
      ctx.lineTo(
        toX - arrowSize * Math.cos(angle - Math.PI / 6),
        toY - arrowSize * Math.sin(angle - Math.PI / 6)
      );
      ctx.lineTo(
        toX - arrowSize * Math.cos(angle + Math.PI / 6),
        toY - arrowSize * Math.sin(angle + Math.PI / 6)
      );
      ctx.closePath();
      ctx.fillStyle = agentColors[msg.to] + '80';
      ctx.fill();
    });
  }, [messages, activeAgents]);

  return (
    <div className="agent-orbit" data-testid="agent-orbit">
      <Card className="p-6 bg-surface border-border">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Activity className="w-6 h-6 text-cyan-400" />
            <div>
              <h2 className="text-xl font-bold">Agent Orbit</h2>
              <p className="text-sm text-slate-400">
                {isConnected ? (
                  <span className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                    Live agent communication
                  </span>
                ) : (
                  'Offline'
                )}
              </p>
            </div>
          </div>
          <Badge variant="outline" className="text-cyan-400 border-cyan-400">
            {messages.length} messages
          </Badge>
        </div>

        {/* Visualization */}
        <div className="flex justify-center mb-6">
          <canvas
            ref={canvasRef}
            width={500}
            height={400}
            className="bg-background/50 rounded-lg"
          />
        </div>

        {/* Message Log */}
        <div className="space-y-2 max-h-[200px] overflow-y-auto">
          <h3 className="text-sm font-semibold text-slate-400 mb-2">Recent Messages</h3>
          {messages.length === 0 ? (
            <div className="text-center text-slate-500 py-4">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No messages yet</p>
            </div>
          ) : (
            messages.slice(-10).reverse().map((msg, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 p-2 bg-background/50 rounded border border-border text-sm"
                data-testid={`message-${idx}`}
              >
                <Badge 
                  style={{ backgroundColor: agentColors[msg.from] + '40', color: agentColors[msg.from] }}
                  className="text-xs"
                >
                  {msg.from}
                </Badge>
                <ArrowRight className="w-4 h-4 text-slate-500" />
                <Badge 
                  style={{ backgroundColor: agentColors[msg.to] + '40', color: agentColors[msg.to] }}
                  className="text-xs"
                >
                  {msg.to}
                </Badge>
                <span className="text-slate-400 flex-1 truncate">
                  {msg.type}
                </span>
                <span className="text-xs text-slate-500">
                  {new Date(msg.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};

export default AgentOrbit;
