import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Toaster, toast } from 'sonner';
import { Sparkles, Cpu, Palette, Code, Server, Shield, Send, Download, Settings, Zap, Brain, Activity } from 'lucide-react';
import { Button } from './components/ui/button';
import { Textarea } from './components/ui/textarea';
import { Card } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Switch } from './components/ui/switch';
import { Label } from './components/ui/label';
import { Slider } from './components/ui/slider';
import { Badge } from './components/ui/badge';
import { ScrollArea } from './components/ui/scroll-area';
import MemoryInspector from './components/MemoryInspector';
import AgentOrbit from './components/AgentOrbit';
import './App.css';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function App() {
  const [prompt, setPrompt] = useState('');
  const [vibes, setVibes] = useState('');
  const [temperature, setTemperature] = useState(0.7);
  const [generating, setGenerating] = useState(false);
  const [currentProject, setCurrentProject] = useState(null);
  const [projects, setProjects] = useState([]);
  const [agents, setAgents] = useState({
    architect: true,
    coder: true,
    designer: true,
    devops: true,
    critic: true
  });
  const [activeTab, setActiveTab] = useState('generate');
  const [generationLogs, setGenerationLogs] = useState([]);
  const [systemInfo, setSystemInfo] = useState(null);
  const logsEndRef = useRef(null);

  useEffect(() => {
    loadProjects();
    loadSystemInfo();
  }, []);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [generationLogs]);

  const loadProjects = async () => {
    try {
      const response = await axios.get(`${API}/emergent/projects`);
      setProjects(response.data.projects || []);
    } catch (error) {
      console.error('Failed to load projects:', error);
    }
  };

  const loadSystemInfo = async () => {
    try {
      const response = await axios.get(`${API}/emergent/system/info`);
      setSystemInfo(response.data);
    } catch (error) {
      console.error('Failed to load system info:', error);
    }
  };

  const addLog = (message, type = 'info') => {
    setGenerationLogs(prev => [...prev, { message, type, timestamp: new Date() }]);
  };

  const generateProject = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a project description');
      return;
    }

    setGenerating(true);
    setGenerationLogs([]);
    addLog('🚀 Initiating Emergent Engine...', 'info');
    addLog(`📝 Request: ${prompt}`, 'info');
    if (vibes) addLog(`🎨 Vibes: ${vibes}`, 'info');

    try {
      addLog('🧠 Parsing intent...', 'info');
      await new Promise(r => setTimeout(r, 500));
      
      addLog('🏗️ ArchitectAgent designing system...', 'agent');
      await new Promise(r => setTimeout(r, 800));
      
      addLog('🎨 DesignerAgent crafting aesthetics...', 'agent');
      await new Promise(r => setTimeout(r, 800));
      
      addLog('💻 CoderAgent writing code...', 'agent');
      await new Promise(r => setTimeout(r, 1000));
      
      addLog('🚀 DevOpsAgent preparing deployment...', 'agent');
      await new Promise(r => setTimeout(r, 800));
      
      addLog('🛡️ CriticAgent reviewing output...', 'agent');
      await new Promise(r => setTimeout(r, 800));

      const response = await axios.post(`${API}/emergent/generate`, {
        prompt,
        vibes,
        temperature
      });

      if (response.data.success) {
        addLog('✅ Project generated successfully!', 'success');
        setCurrentProject(response.data.project);
        setActiveTab('preview');
        loadProjects();
        toast.success('Project generated! 🎉');
      } else {
        addLog(`❌ Generation failed: ${response.data.error}`, 'error');
        toast.error('Generation failed');
      }
    } catch (error) {
      addLog(`❌ Error: ${error.message}`, 'error');
      toast.error('Failed to generate project');
      console.error('Generation error:', error);
    } finally {
      setGenerating(false);
    }
  };

  const toggleAgent = async (agentName) => {
    const newState = !agents[agentName];
    setAgents(prev => ({ ...prev, [agentName]: newState }));
    
    try {
      await axios.post(`${API}/emergent/agent/toggle`, {
        agent_name: agentName,
        enabled: newState
      });
      toast.success(`${agentName} agent ${newState ? 'enabled' : 'disabled'}`);
    } catch (error) {
      console.error('Failed to toggle agent:', error);
    }
  };

  const downloadProject = () => {
    if (!currentProject) return;
    
    const dataStr = JSON.stringify(currentProject, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentProject.name || 'emergent-project'}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Project downloaded!');
  };

  const AgentIcon = ({ name }) => {
    const icons = {
      architect: <Server className="w-4 h-4" />,
      coder: <Code className="w-4 h-4" />,
      designer: <Palette className="w-4 h-4" />,
      devops: <Zap className="w-4 h-4" />,
      critic: <Shield className="w-4 h-4" />
    };
    return icons[name] || <Cpu className="w-4 h-4" />;
  };

  return (
    <div className="app-container">
      <Toaster position="top-right" richColors />
      
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <div className="logo-section">
            <Sparkles className="w-8 h-8 text-cyan-400" />
            <div>
              <h1 className="text-2xl font-bold">Emergent.sh</h1>
              <p className="text-sm text-slate-400">
                Offline Agentic Platform — {systemInfo?.phase || 'Phase 3.0'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="status-badge">
              <span className="status-dot"></span>
              {systemInfo?.agent_bus?.connected ? 'Agent Bus Active' : 'Offline Mode'}
            </Badge>
            {systemInfo?.active_vibe && (
              <Badge variant="outline" className="border-purple-500 text-purple-400">
                Vibe: {systemInfo.active_vibe}
              </Badge>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="tabs-list">
            <TabsTrigger value="generate" data-testid="tab-generate">Generate</TabsTrigger>
            <TabsTrigger value="preview" data-testid="tab-preview">Preview</TabsTrigger>
            <TabsTrigger value="projects" data-testid="tab-projects">Projects</TabsTrigger>
            <TabsTrigger value="memory" data-testid="tab-memory">
              <Brain className="w-4 h-4 mr-2" />
              Memory
            </TabsTrigger>
            <TabsTrigger value="orbit" data-testid="tab-orbit">
              <Activity className="w-4 h-4 mr-2" />
              Agent Orbit
            </TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
          </TabsList>

          {/* Generate Tab */}
          <TabsContent value="generate" className="tab-content">
            <div className="generate-layout">
              {/* Left: Input */}
              <Card className="input-card">
                <h2 className="card-title">Describe Your App</h2>
                <p className="card-description">
                  Use natural language to describe what you want to build. Be as detailed or as vague as you like.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="prompt">Project Description</Label>
                    <Textarea
                      id="prompt"
                      data-testid="prompt-input"
                      placeholder="E.g., Create a mood-based journaling app with daily AI reflections and a calm, oceanic vibe..."
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="prompt-textarea"
                      rows={6}
                    />
                  </div>

                  <div>
                    <Label htmlFor="vibes">Vibe Keywords (optional)</Label>
                    <Textarea
                      id="vibes"
                      data-testid="vibes-input"
                      placeholder="E.g., cosmic, serene, futuristic, minimal..."
                      value={vibes}
                      onChange={(e) => setVibes(e.target.value)}
                      className="vibes-textarea"
                      rows={2}
                    />
                  </div>

                  <div>
                    <Label>Temperature: {temperature.toFixed(1)}</Label>
                    <Slider
                      value={[temperature]}
                      onValueChange={(v) => setTemperature(v[0])}
                      min={0.1}
                      max={1.0}
                      step={0.1}
                      className="mt-2"
                      data-testid="temperature-slider"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Higher = more creative, Lower = more focused
                    </p>
                  </div>

                  <Button
                    onClick={generateProject}
                    disabled={generating}
                    className="generate-button"
                    data-testid="generate-button"
                  >
                    {generating ? (
                      <>
                        <Cpu className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate Project
                      </>
                    )}
                  </Button>
                </div>
              </Card>

              {/* Right: Logs */}
              <Card className="logs-card">
                <h2 className="card-title">Generation Logs</h2>
                <ScrollArea className="logs-scroll" data-testid="generation-logs">
                  {generationLogs.length === 0 ? (
                    <div className="logs-empty">
                      <Cpu className="w-12 h-12 text-slate-600 mb-2" />
                      <p className="text-slate-400">Logs will appear here during generation</p>
                    </div>
                  ) : (
                    <div className="logs-content">
                      {generationLogs.map((log, idx) => (
                        <div key={idx} className={`log-entry log-${log.type}`}>
                          <span className="log-time">
                            {log.timestamp.toLocaleTimeString()}
                          </span>
                          <span className="log-message">{log.message}</span>
                        </div>
                      ))}
                      <div ref={logsEndRef} />
                    </div>
                  )}
                </ScrollArea>
              </Card>
            </div>
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview" className="tab-content">
            {currentProject ? (
              <Card className="preview-card">
                <div className="preview-header">
                  <div>
                    <h2 className="text-2xl font-bold">{currentProject.name}</h2>
                    <p className="text-slate-400 mt-1">{currentProject.description}</p>
                  </div>
                  <Button onClick={downloadProject} data-testid="download-button">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>

                <Tabs defaultValue="architecture" className="mt-6">
                  <TabsList>
                    <TabsTrigger value="architecture">Architecture</TabsTrigger>
                    <TabsTrigger value="design">Design</TabsTrigger>
                    <TabsTrigger value="code">Code</TabsTrigger>
                    <TabsTrigger value="deployment">Deployment</TabsTrigger>
                    <TabsTrigger value="critique">Critique</TabsTrigger>
                  </TabsList>

                  <TabsContent value="architecture" className="preview-section">
                    <pre className="code-preview">
                      {JSON.stringify(currentProject.architecture, null, 2)}
                    </pre>
                  </TabsContent>

                  <TabsContent value="design" className="preview-section">
                    <pre className="code-preview">
                      {JSON.stringify(currentProject.design, null, 2)}
                    </pre>
                  </TabsContent>

                  <TabsContent value="code" className="preview-section">
                    <pre className="code-preview">
                      {JSON.stringify(currentProject.files, null, 2)}
                    </pre>
                  </TabsContent>

                  <TabsContent value="deployment" className="preview-section">
                    <pre className="code-preview">
                      {JSON.stringify(currentProject.deployment, null, 2)}
                    </pre>
                  </TabsContent>

                  <TabsContent value="critique" className="preview-section">
                    <pre className="code-preview">
                      {JSON.stringify(currentProject.critique, null, 2)}
                    </pre>
                  </TabsContent>
                </Tabs>
              </Card>
            ) : (
              <Card className="preview-empty">
                <Code className="w-16 h-16 text-slate-600 mb-4" />
                <p className="text-lg text-slate-400">No project generated yet</p>
                <Button onClick={() => setActiveTab('generate')} className="mt-4">
                  Start Generating
                </Button>
              </Card>
            )}
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="tab-content">
            <div className="projects-grid">
              {projects.length === 0 ? (
                <Card className="preview-empty">
                  <Sparkles className="w-16 h-16 text-slate-600 mb-4" />
                  <p className="text-lg text-slate-400">No projects yet</p>
                </Card>
              ) : (
                projects.map((project) => (
                  <Card
                    key={project.id}
                    className="project-card"
                    onClick={() => {
                      setCurrentProject(project);
                      setActiveTab('preview');
                    }}
                    data-testid={`project-${project.id}`}
                  >
                    <h3 className="font-bold text-lg">{project.name}</h3>
                    <p className="text-sm text-slate-400 mt-2 line-clamp-2">
                      {project.description}
                    </p>
                    <div className="mt-4 flex justify-between items-center">
                      <Badge variant="secondary">{project.status}</Badge>
                      <span className="text-xs text-slate-500">
                        {new Date(project.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Memory Inspector Tab */}
          <TabsContent value="memory" className="tab-content">
            <MemoryInspector sessionId={emergent.current_session_id} />
          </TabsContent>

          {/* Agent Orbit Tab */}
          <TabsContent value="orbit" className="tab-content">
            <AgentOrbit />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="tab-content">
            <div className="settings-layout">
              <Card className="settings-card">
                <h2 className="card-title">Agent Controls</h2>
                <p className="card-description">
                  Toggle individual agents on or off to customize the generation pipeline.
                </p>
                
                <div className="agents-grid">
                  {Object.keys(agents).map((agentName) => (
                    <div key={agentName} className="agent-control">
                      <div className="agent-info">
                        <AgentIcon name={agentName} />
                        <Label htmlFor={agentName} className="capitalize">
                          {agentName}Agent
                        </Label>
                      </div>
                      <Switch
                        id={agentName}
                        checked={agents[agentName]}
                        onCheckedChange={() => toggleAgent(agentName)}
                        data-testid={`agent-toggle-${agentName}`}
                      />
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="settings-card">
                <h2 className="card-title">Model Configuration</h2>
                <p className="card-description">
                  Configure Hugging Face models for offline generation.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <Label>Current Model</Label>
                    <div className="model-display">
                      <Cpu className="w-5 h-5 text-cyan-400" />
                      <span>{systemInfo?.model_router?.active_provider || 'Simulated Mode'}</span>
                      <Badge variant="outline">Active</Badge>
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-400">
                    To use real Hugging Face models, load a model via the API or configure in backend settings.
                  </p>
                </div>
              </Card>

              <Card className="settings-card">
                <h2 className="card-title">Phase 3 System Status</h2>
                <p className="card-description">
                  Advanced intelligence and communication layer status.
                </p>
                
                <div className="space-y-3 mt-4">
                  <div className="flex items-center justify-between p-3 bg-background rounded border border-border">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-cyan-400" />
                      <span className="text-sm">Agent Bus</span>
                    </div>
                    <Badge variant={systemInfo?.agent_bus?.connected ? 'default' : 'secondary'}>
                      {systemInfo?.agent_bus?.connected ? 'Connected' : 'Offline'}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-background rounded border border-border">
                    <div className="flex items-center gap-2">
                      <Brain className="w-4 h-4 text-purple-400" />
                      <span className="text-sm">Reflective Memory</span>
                    </div>
                    <Badge variant={systemInfo?.memory?.redis_connected ? 'default' : 'secondary'}>
                      {systemInfo?.memory?.redis_connected ? 'Active' : 'Offline'}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-background rounded border border-border">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span className="text-sm">Task Graphs</span>
                    </div>
                    <Badge variant="outline">
                      {systemInfo?.task_graph?.active_graphs || 0} active
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-background rounded border border-border">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-pink-400" />
                      <span className="text-sm">CoT Buffer</span>
                    </div>
                    <Badge variant="outline">
                      {systemInfo?.cot_buffer?.active_sessions || 0} sessions
                    </Badge>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

export default App;
